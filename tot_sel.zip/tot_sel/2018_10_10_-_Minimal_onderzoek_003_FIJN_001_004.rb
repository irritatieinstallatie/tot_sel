#reich

use_bpm 100

set_volume! 1.0

# tiny
#  house
#   on thee

'

live_loop :onderzoek do
  #  xiop = line(4, 12, steps: 8).choose
  with_synth :hoover do
    with_fx :gverb, room: (line 7,20, steps: 13).choose do
      7.times do
        play 44, amp: 1, attack: 0.125, attack_level: 1, decay: 0, sustain: 0.01, release: rrand(0.01, 0.1)
        sleep (ring 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.5, 0.25, 0.5, 0.25, 0.5).tick
      end
      7.times do
        play 47, amp: 1, attack: 0.125, attack_level: 1, decay: 0, sustain: 0.01, release: rrand(0.01, 0.1)
        sleep (ring 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.5, 0.25, 0.5, 0.25, 0.5).choose
      end
      7.times do
        play 46, amp: 1, attack: 0.125, attack_level: 1, decay: 0, sustain: 0.01, release: rrand(0.01, 0.1)
        sleep (ring 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.5, 0.25, 0.5, 0.25, 0.5).tick
      end
      7.times do
        play 45, amp: 1, attack: 0.125, attack_level: 1, decay: 0, sustain: 0.01, release: rrand(0.01, 0.1)
        sleep (ring 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.5, 0.25, 0.5, 0.25, 0.5).choose
      end

      sleep 1
    end
  end
end




live_loop :laaka do

  with_synth :tb303 do
    with_fx :bitcrusher, bits: (line 2, 8, steps: 6).choose  do

      21.times do
        play 121, amp: 0.5, attack: 0.01, attack_level: 0.75, sustain: 0.0125, decay: 0.0125, decay_level: 0.0125, release: 0.05

        play 66
        play 41, amp: 0.5#, attack: 0.01, attack_level: 0.5, sustain: 0.0125, decay: 0.0125, decay_level: 0.0125, release: 0.05
        sleep 0.25
      end
      sleep (ring 1, 2, 3).tick
      #    play rrand_i(20, 40), amp: 1, attack: 0.1, sustain: rrand(0.1, 2), release: 0.1
      play rrand_i(28, 48), amp: 1, attack: 0.1, sustain: rrand(0.1, 2), release: 0.1
      #play rrand_i(24, 44), amp: 1, attack: 0.1, sustain: rrand(0.1, 2), release: 0.1
      if one_in(2)
        21.times do
          play 121, amp: 0.5, attack: 0.01, attack_level: 0.75, sustain: 0.0125, decay: 0.0125, decay_level: 0.0125, release: 0.05
          #sleep 0.25

          play 31, amp: 0.5#, attack: 0.01, attack_level: 0.5, sustain: 0.0125, decay: 0.0125, decay_level: 0.0125, release: 0.05
          sleep 0.25
        end
        sleep (ring 1, 2, 3).tick
        play rrand_i(20, 40), amp: 1, attack: 0.1, sustain: rrand(0.1, 2), release: 0.1
        play rrand_i(28, 48), amp: 1, attack: 0.1, sustain: rrand(0.1, 2), release: 0.1
        #play rrand_i(24, 44), amp: 1, attack: 0.1, sustain: rrand(0.1, 2), release: 0.1
      else
        sleep rrand(0,1)
      end
    end
  end
end

'

live_loop :brandendezee do
  with_synth :mod_saw do
    
    with_fx :gverb, room: (line 1, 20, steps: 20).choose do
      
      3.times do
        
        play 58, sustain: 3
        play 37, sustain: 3
        play 66, sustain: 3
        
        sleep 3
      end
      #      sleep 0.5
      3.times do
        
        play 57, sustain: 3
        play 38, sustain: 3
        play 65, sustain: 3
        
        sleep 3
      end
      1.times do
        #        play (ring rrand(54, 62), rrand(37,41), rrand(61,66)), sustain: 3
        play rrand(54, 62), sustain: 9
        play rrand(37,41), sustain: 9
        play rrand(61,66), sustain: 9
        
        sleep 3
      end
      sleep 0.5
    end
  end
end





