set_volume! 1


use_bpm 100
vrtg=49
use_random_seed 101

amp1 = 0.25

a=10
b=10
c=10
d=10

live_loop :opena do
  with_synth :square do
    with_fx :gverb, room: 22 do
      #      7.times do
      #        play (ring 41, 57, 69), amp: 1, attack: 0.0125, decay: 0.125, release: 0.0125
      #      sleep 0.5
      #     end
      a.times do
        play (ring 32, 34, 69), amp: 3, attack: 0.0125, decay: 0.0675, release: 0.0125
        play (ring 62, 35, 33), amp: 3, attack: 0.0125, decay: 0.0675, release: 0.0125
        sleep (ring 0.25, 0.5).tick
      end
      b.times do
        play (ring 67, 35, 33), amp: 3, attack: 0.0125, decay: 0.0675, release: 0.0125
        play (ring 65, 35, 33), amp: 3, attack: 0.0125, decay: 0.0675, release: 0.0125
        sleep 0.25
      end
      c.times do
        play (ring 67, 35, 33), amp: 3, attack: 0.0125, decay: 0.0675, release: 0.0125
        play (ring 32, 34, 69), amp: 3, attack: 0.0125, decay: 0.0675, release: 0.0125
        sleep (ring 0.25, 0.5).tick
      end
      d.times do
        play (ring 67, 35, 33), amp: 3, attack: 0.0125, decay: 0.0675, release: 0.0125
        play (ring 65, 35, 33), amp: 3, attack: 0.0125, decay: 0.0675, release: 0.0125
        sleep 0.25
      end
    end
  end
end




'

live_loop :klopt do
  with_synth :dark_ambience do
    
    with_fx :gverb, room: 7 do
      
      3.times do
        play 66, amp: 7, attack: 0.125, sustain: 1.25, release: 0.125
        sleep 0.1
        play 66, amp: 7, attack: 0.125, sustain: 1.25, release: 0.125
        sleep 0.75
      end
      20.times do
        play rrand(55,66), amp: 22, attack: 0.0125, sustain: 0.1, release: 0.0125
        sleep 0.25
      end
      sleep 1#rrand(2,4)
      3.times do
        play 65, amp: 7, attack: 0.125, sustain: 1.25, release: 0.125
        sleep 0.1
        play 67, amp: 7, attack: 0.125, sustain: 1.25, release: 0.125
        sleep 0.75
      end
      20.times do
        play rrand(55,66), amp: 22, attack: 0.0125, sustain: 0.1, release: 0.0125
        sleep 0.25
      end
      sleep 1#rrand(2,4)
      
    end
  end
end







live_loop :klodder do
  with_synth :hoover do
    with_fx :gverb, room: 20 do
      
      20.times do
        play (line 62, 72, steps: 10).mirror.tick, amp: 1.0, attack: 0.0125, sustain: 0.05, release: 0.0125
        sleep (ring 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.125, 0.25).tick
      end
      #      3.times do
      #      play rrand(30,34), amp: 7, attack: 0.125, release: 0.125
      #       sleep 0.25
      #    end
      #   7.times do
      #       play rrand(41,45), amp: 7, attack: 0.125, release: 0.125
      #    sleep 0.25
      # end
      #3.times do
      #        play rrand(30,34), amp: 7, attack: 0.125, release: 0.125
      # sleep 0.25
      #end
      #      sleep 0.5# rrand(3,5)
    end
  end
end



'
