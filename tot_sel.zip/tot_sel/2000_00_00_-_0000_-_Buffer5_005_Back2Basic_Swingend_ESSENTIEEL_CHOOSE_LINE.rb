#2019_01_29_-_1507_-_Buffer5_005_Back2Basic_Swingend_ESSENTIEEL_CHOOSE_LINE

use_random_seed 313
use_bpm 120

#
# BACK TO BASICS
#
# BACK TO SWIMG
#
#
#


set_volume! 1


a01 = 2
s01 = 0.25
st01 = (ring 1,0.5,1,0.5,0.25,0.25,0.5,1)

set_volume! 0.9
live_loop :zekersteonders do
  #flias  = (line: 100, 160, steps: 60)
  #use_bpm 120
  #use_bpm (line 100, 160, steps: 6).reflect.tick
  with_synth :piano do
    with_fx :gverb, room: 77 do
      with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
        #with_fx :level do
        14.times do

          #         play 27, amp: a01, attack: 0.0125, decay: 0, sustain: a01, release: 0.0125
          #          play (line 20, 32, steps: 10).choose, amp: a01, attack: 0.125, sustain: st01.tick, release: 0.125
          sleep s01*(ring 1,1,2,1,2).stretch(2).tick
          #      play 66
          #      sleep 1
          #      play 44
          #      sleep 1
        end
        #        sleep 1
      end
      #     end
    end
  end
end


live_loop :minaers do
  #use_bpm 120
  with_synth :tb303 do
    with_fx :gverb, room: 77 do
      2.times do
        32.times do
          with_fx :bitcrusher,
            bits: 1,
          sample_rate: 4400 do
            #            with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
            play (ring 67, rrand(44,88)).choose, amp: 1,
              attack: 0.0125,
              sustain: 0.0,
              decay: 0,
              release: 0.125,
              wave: 1, res: (ring 0.25, 0.5, 0.95).tick
            sleep (ring 0.5, 0.25, 0.25, 0.5, 0.25).tick
            #end
          end
        end
        if one_in(2)
          #          play 98, amp: rrand(1, 7), attack: 0.0125, release: 0.0625
          sleep 0.5
        else
          #         play 77, amp: 1, attack: 0.0125, release: 0.0625
          sleep 0.5
        end

        #        play rrand(90, 110), amp: 2, attack: rrand(0, 1)
      end

    end
  end
end

live_loop :minaers2 do
  #use_bpm 120
  with_synth :tb303 do
    with_fx :gverb, room: 77 do
      2.times do
        32.times do
          with_fx :slicer, pulse_width: 0.125, phase: 0.5 do
            with_fx :bitcrusher,
              bits: 1,
            sample_rate: 4400 do
              #            with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
              play (ring 67, rrand(44,88)), amp: 1,
                attack: 0.0125,
                sustain: 0.0,
                decay: 0,
                release: 0.125,
                wave: 1, res: (ring 0.5, 0.5, 0.95).tick
              with_fx :slicer do
                play (line 52, 60, steps: 8).choose, amp: 1,
                  attack: 0.0125,
                  sustain: 0.0,
                  decay: 0,
                  release: 0.125,
                  wave: 1, res: (ring 0.5, 0.5, 0.95).tick
                sleep 0.5
                #end
              end
            end
          end
          if one_in(2)
            #          play 98, amp: rrand(1, 7), attack: 0.0125, release: 0.0625
            sleep 0.5
          else
            #         play 77, amp: 1, attack: 0.0125, release: 0.0625
            sleep 0.5
          end

          #        play rrand(90, 110), amp: 2, attack: rrand(0, 1)
        end
      end
    end
  end
end






live_loop :zambuba do
  #use_bpm 100
  with_fx :bitcrusher,
    bits: (ring 1,2,3,4,8,16).tick,
    sample_rate: 44000,
  cutoff: 50 do
    with_fx :slicer,
      phase: (ring 0.5, 0.25, 0.125, 0.125).tick,
    pulse_width: 0.5 do
      32.times do
        play (line 90, 40, steps: 16).choose,
          #play (line 90, 40, steps: 16).reflect.choose,
          amp: (line 1, 14.0, steps: 16).reflect.choose,
          attack: 0.125, sustain: 0.25, release: 0.125
        sleep 0.25
      end
    end
  end
end
