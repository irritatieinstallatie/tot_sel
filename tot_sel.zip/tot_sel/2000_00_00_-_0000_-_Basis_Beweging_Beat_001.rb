
live_loop :minaers do
  #use_bpm 120
  with_synth :tb303 do
    with_fx :gverb, room: 77 do
      2.times do
        7.times do
          with_fx :bitcrusher, bits: 1, sample_rate: 4400 do
            #            with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
            play 67, amp: 1, attack: 0.0125, sustain: 0.0, decay: 0, release: 0.125, wave: 1, res: (ring 0.5, 0.5, 0.95).tick
            sleep 0.5
            #end
          end
        end
        if one_in(2)
          play 98, amp: rrand(1, 7), attack: 0.0125, release: 0.0625
          sleep 0.5
        else
          play 77, amp: 1, attack: 0.0125, release: 0.0625
          sleep 0.5
        end
        
        #        play rrand(90, 110), amp: 2, attack: rrand(0, 1)
      end
      
    end
  end
end


