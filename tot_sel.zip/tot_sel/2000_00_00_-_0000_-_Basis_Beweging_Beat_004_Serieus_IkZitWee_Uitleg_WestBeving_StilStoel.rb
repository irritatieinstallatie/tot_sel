



set_volume! 0.975




live_loop :ikzitwee do
  use_bpm 60
  10.times do
    
    #    with_synth :piano do
    with_synth :tb303 do
      with_fx :gverb, room: 22 do
        with_fx :krush do
          with_fx :nrhpf do
            #          with_fx :ixi_techno do
            with_fx :slicer, phase: 0.125, pulse_width: (line 0.25, 0.4, steps: 4).choose do
              with_fx :nrbpf do
                1.times do
                  14.times do
                    #                    play (line 70, 92, steps: 32).choose,
                    #                     amp: 7,
                    #                    attack: 0.0,
                    #                   decay: 0,
                    #                  sustain: 0.0125,
                    #                 release: 0.0125
                    play (ring 68, 70, 71, 70, 69, 72, 73, 74).choose,
                      amp: 7,
                      attack: 0.0,
                      decay: 0,
                      sustain: 0.0125,
                      release: 0.0125
                    #              play (line 69, 90, steps: 10).choose,
                    #               amp: 7,
                    #              attack: 0.0,
                    #             decay: 0,
                    #            sustain: 0.0125,
                    #           release: 0.0125
                    sleep 0.125
                    #                    sleep (line 0.125, 0.15).tick
# DUCK FADE                    
                    #                    play (line 40, 50, steps: 10).choose, amp: 3, attack: 0.125, decay: 0.25, sustain: 0.25, release: 0.125
                    #                   sleep 0.35
                    play (line 80, 70, steps: 10).choose, amp: 1, attack: rrand(0, 1), decay: rrand(0, 1), sustain: rrand(0, 1), release: rrand(0, 1)
                    sleep 1.5
                  end
                end
                
              end
              sleep rrand(0.01, 0.05)
            end
          end
        end
      end
      #        sleep 1
    end
    #   end
    # end
  end
end
















live_loop :beat do
  print   sample_duration :loop_amen
  #  sample :loop_amen, rate: 1.5
  sleep (line 1, 1.125, steps: 10).tick
end

