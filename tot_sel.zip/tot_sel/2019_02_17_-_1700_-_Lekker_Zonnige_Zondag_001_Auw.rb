#use_bpm 120

live_loop :minaers do
  #use_bpm 120
  xiffit  = rrand_i(22,36)
  with_synth :mod_dsaw do
    with_fx :gverb, room: 77 do
      #      with_fx :krush do
      2.times do
        xiffit.times do
          with_fx :bitcrusher, bits: 1, sample_rate: 4400 do
            #            with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
            sleep 0.25
            #            play 24,
            play (line 24, 35, steps: xiffit).choose,
              amp: 1, attack: 0.12, sustain: 0.1, decay: 0, release: 0.12, wave: 1, res: (ring 0.5, 0.5, 0.95).tick
            #sleep xiffit*0.125*0.25
            #            sleep (ring 0.5, 0.5, 0.5, 0.5, 0.5, 0.375).stretch(3).choose
            #end
          end
          with_fx :distortion  do
            if one_in(2)
              cue :aab1
              play (ring 39, 48, 58, 78),
                amp: rrand(1, 7),
                attack: 0.0125,
                sustain: 0.0,
                release: 0.0625
              sleep 0.01
            else
              cue :aab2
              play (ring 28, 39, 67, 81),
                amp: rrand(1,7),
                attack: 0.0125,
                sustain: 0.0,
                release: 0.0625
              sleep 0.01
              if one_in(2)
                play (ring 28, 39, 97, 81, 7),
                  amp: rrand(1,7),
                  attack: 0.0125,
                  sustain: 0.5,
                  release: 0.0625
                sleep 0.01
              else
                play (ring 38, 39, 87, 81),
                  amp: rrand(1,7),
                  attack: 0.0125,
                  sustain: 0.0,
                  release: 0.0625
                sleep 0.01
              end
            end
          end
        end
        #        sleep rrand(0,1)
        #        play rrand(90, 110), amp: 2, attack: rrand(0, 1)
      end
      sleep rrand(0,1)
      #     end
    end
  end
end





use_sample_bpm :ambi_piano

live_loop :beat_slicer do
  
  with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
    
    n = 8
    
    
    d = 1.0 / n
    
    
    s = (line 0, 1, steps: n).choose
    
    
    f = s + d
    
    #    sample :ambi_piano, amp: 22,  start: s, finish: f
    
    sleep d
  end
end

