live_loop :II060D_G do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, spread: 0.5, dry: 4, room: 55 do
      with_fx :ixi_techno, phase: 1,
        res: 0.5,
      mix: 0.5 do
        12.times do
          #          play 33, amp: 1,
          #       attack: 0.05, sustain: 0.25, release: 0.05
          #         play 59, amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
          #        play 47, amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
          play (ring 53, 39, 57, 81, 96), amp: 1,
            attack: 0.001, sustain: 0.5, release: 0.001,
            wave: 2
          sleep 2
        end
      end
    end
  end
end
