set_volume! 1

live_loop :II090BA1CCA do
  l48 = rrand_i(4,8)
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: 4,
    sample_rate: 44000 do
      #      with_fx :flanger, delay: 0.25, mix: 0.125 do
      with_fx :reverb, damp: 0.5, room: 0.75, mix: 0.5 do
        with_fx :gverb, spread: 0.4, dry: 4, room: 88, mix: 0.5 do
          l48.times  do
            play 25,
              amp: 1,
              attack: 0.01,
              attack_level: 0,
              decay: 0.05,
              decay_level: 1,
              sustain: 0.125,
              release: 0.01,
              res: 0.005,
              wave: 2
            play 26,
              amp: 1,
              attack: 0.01,
              attack_level: 0,
              decay: 0.05,
              decay_level: 1,
              sustain: 0.125,
              release: 0.01,
              res: 0.005,
              wave: 2
            sleep 0.5
          end
        end
      end
      #     end
    end
  end
end
