live_loop :G2022_03_12_095A_1D do
  use_bpm 100
  n0 = 36
  n02 = 37
  n1 = 24
  n2 = 23
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: (line 2,4, steps: 10).tick,
    sample_rate: 44000 do
      12.times do
        play n0,
          amp: (ring 3,1).tick,
          attack: 0.05,
          sustain: (stretch [0.25],4,[1],1).reflect.tick,
          release: 0.05,
          wave: 2
        play n02,
          amp: (ring 1,3).tick,
          attack: 0.05,
          sustain: (stretch [0.25],4,[1],1).reflect.tick,
          release: 0.05,
          wave: 2
        play n1,
          amp: (ring 1,2).tick,
          attack: 0.05,
          sustain: (stretch [0.25],4,[1],1).reflect.tick,
          release: 0.05,
          wave: 2
        play n1+0.25, amp: 1,
          attack: 0.05,
          sustain: (stretch [0.25],20,[1],1,[0.5],6).reflect.tick,
          release: 0.05,
          wave: 2
        play n1+0.5,
          amp: rrand(0,1),
          attack: 0.001,
          sustain: (stretch [0.5],4,[1],6,[0.25],4,[0.5],4).reflect.tick,
          release: 0.001,
          wave: 0
        play n2,
          amp: 2,
          attack: 0.05,
          sustain: (stretch [0.5],2,[1],6,[0.25],4).reflect.tick,
          release: 0.05,
          wave: 2
        sleep (ring 1, 0.5, 0.25, 0.5).tick
      end
    end
  end
end
