live_loop :II160EA do
  set_volume! 1.0
  use_bpm 100
  n1 = 28
  n2 = 29
  n3 = 70
  rc10 = rrand_i(5,15)
  with_synth :tb303 do
    with_fx :gverb, spread: 0.125, dry: 2, room: 55, mix: 0.125 do
      with_fx :krush, res: 0.5, gain: 0.25 do
        with_fx :bitcrusher,
          bits: 4,
          #      bits: rrand_i(2,7),
        sample_rate: 44000 do
          rc10.times do
            play n1,
              amp: 1,
              attack: 0.001,
              sustain: 0.25,
              release: 0.001,
              wave: 2
            play n1+0.25,
              amp: 0.125,
              attack: 0.001,
              sustain: 0.25,
              release: 0.001,
              wave: 2
            play n1+0.5,
              amp: 0.125,
              attack: 0.001,
              sustain: 0.25,
              release: 0.001,
              wave: 2
            play n2,
              amp: 1,
              attack: 0.001,
              sustain: 0.25,
              release: 0.001,
              wave: 2
            play n3,
              amp: 1,
              attack: 0.001,
              sustain: 0.25,
              release: 0.001,
              wave: 2
            sleep 1.5
          end
        end
      end
    end
  end
end
