live_loop :G2022_01_07_017CI do
  use_random_seed 110
  use_bpm 100
  n0 = rrand_i(16,24)
  with_synth :tb303 do
    with_fx :gverb, spread: 0.25, dry: 4.0, room: 55 do
      with_fx :bitcrusher,
      bits: (ring 1.0, 2.5).tick, sample_rate: 22000 do
        n0.times do
          play 69,
            amp: 1,
            attack: 0.01,
            attack_level: 0.5,
            sustain: 0.0125,
            release: 0.075,
            wave: 1
          play 70,
            amp: 0.25,
            attack: 0.01,
            attack_level: 0.5,
            sustain: 0.0125,
            release: 0.075,
            wave: 2
          play 31,
            amp: 0.5,
            attack: 0.01,
            attack_level: 0.75,
            sustain: 0.0125,
            decay: 0.2,
            decay_level: 0.0125,
            release: 0.125,
            wave: 0
          sleep 0.25
        end
        sleep rrand(0,0.125)
      end      
    end
  end
end
