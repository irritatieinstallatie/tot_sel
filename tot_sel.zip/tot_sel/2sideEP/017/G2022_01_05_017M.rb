live_loop :G2022_01_07_017M do
  use_bpm 100
  n0 = rrand_i(1,16)
  with_synth :tb303 do
    with_fx :gverb, spread: 0.75, dry: 2, room: 55 do
      with_fx :slicer,
        phase: 0.99,
      pulse_width: rrand(0.75,0.99) do
        with_fx :bitcrusher,
        bits: (stretch [4],5,[rrand_i(1,5)],3).tick do
          n0.times do
            play 62, amp: 1,
              attack: 0.01,
              sustain: 0.0125,
              release: 0.1
            play 31,
              sustain: 0.0125,
              amp: 1
            sleep 0.25
          end
        end
      end
    end
  end
end
