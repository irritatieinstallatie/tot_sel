live_loop :II123A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, spread: 0.5, dry: 4, room: 77 do
      with_fx :bitcrusher,
        bits: 16,
      sample_rate: 44000 do
        with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
          16.times do
            play 69,
              amp: 0.5,
              attack: 0.0125,
              #sustain: 0.125,
              sustain: (line 0.125, 0.25, steps: 16).tick,
              decay: 0, release: 0.125,
              wave: 2,
              res: (ring 0.5, 0.5, 0.5, 0.25).tick
            play 79,
              amp: 0.5,
              attack: 0.0125,
              #           sustain: 0.125,
              sustain: (line 0.125, 0.25, steps: 16).tick,
              decay: 0, release: 0.125,
              wave: 0,
              res: (ring 0.5, 0.5, 0.5, 0.25).tick
            play 33, amp: 1,
              amp: rrand(1,2),
              sustain: 0.0675,
              wave: 2
            sleep 0.25
          end
        end
      end
    end
  end
end
