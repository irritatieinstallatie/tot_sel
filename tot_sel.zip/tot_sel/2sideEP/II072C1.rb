live_loop :II072C1 do
  set_volume! 1
  srn = rrand(440,44000)
  rn1 = rrand_i(9,12)
  use_bpm 120
  with_synth :tb303 do
    with_fx :gverb, room: 77 do
      with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
        rn1.times do
          with_fx :bitcrusher,
            bits: 4,
            #sample_rate: srn do
          sample_rate: 44000 do
            with_fx :lpf do
              play 29,
                amp: 1.5,
                attack: 0.001,
                sustain: 0.5,
                decay: 0, release: 0.001,
                wave: 2,
                res: 0.125
              sleep 1
            end
          end
        end
      end
    end
  end
end
