live_loop :G2022_07_28_138AC do
  set_volume! 1
  use_bpm 100
  n1 = 27
  n2 = 28
  rc10 = (ring 2,4,6,8).mirror.tick
  with_synth :tb303 do
    with_fx :reverb,
      room: 0.5,
      pre_amp: 0.5,
    mix: 0.5 do
      with_fx :bitcrusher,
        bits: (line 5,1,steps: 20).reflect.tick,
      sample_rate: 44000 do
        rc10.times do
          play n1,
            amp: (ring 0.125,0.25,0.5,1).mirror.tick,
            attack: 0.05,
            sustain: 0.5,
            release: 0.05,
            res: 0.75,
            wave: 2
          play n1,
            amp: (ring 1,2).tick,
            attack: 0.05,
            sustain: 0.5,
            release: 0.05,
            res: 0.75,
            wave: 2
          play n1+0.25,
            amp: (ring 1,2).tick,
            attack: 0.05,
            sustain: 0.5,
            release: 0.05,
            res: 0.75,
            wave: 2
          play n1+0.5,
            amp: (ring 1,2).tick,
            attack: 0.05,
            sustain: 0.5,
            release: 0.05,
            res: 0.75,
            wave: 2
          play n2,
            amp: (ring 2,1).tick,
            attack: 0.05,
            sustain: 0.5,
            release: 0.05,
            res: 0.001,
            wave: 0
          play 50,
            amp: 1,
            attack: 0.05,
            sustain: 0.125,
            release: 0.05,
            res: 0.001,
            wave: 0
          sleep (ring 0.25, 0.5).reflect.tick
        end
      end
    end
  end
end
