live_loop :G2022_03_12_094ACC do
  use_bpm 100
  n0 = 27
  n1 = 28
  n2 = 29
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: (ring 2,4,3,2).tick,
    sample_rate: rrand_i(22000, 44000) do
      20.times do
        play n0,
          amp: (ring 0,1).tick,
          attack: 0.001,
          sustain: 0.25,
          release: 0.001,
          wave: 2
        play n1,
          amp: (ring 0,1).tick,
          attack: 0.001,
          sustain: 0.25,
          release: 0.001,
          wave: 2
        play n1+0.25,
          amp: (ring 0,1).tick,
          attack: 0.001,
          sustain: 0.25,
          release: 0.001,
          wave: 2
        play n1+0.5,
          amp: (ring 0,1).tick,
          attack: 0.001,
          sustain: 0.25,
          release: 0.001,
          wave: 2
        play n2,
          amp: 0.5,
          attack: 0.00125,
          sustain: 1,
          release: 0.125,
          wave: 2
        sleep (stretch [0.25],rrand_i(5,15),
               [0.5],2
               ).mirror.tick
      end
    end
  end
end
