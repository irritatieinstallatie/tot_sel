live_loop :II_144 do
  use_bpm 100
  with_synth :tb303 do
    with_fx :reverb, room: 0.5, mix: 0.5 do
      with_fx :gverb, spread: 0.5, dry: 4, room: 55 do
        with_fx :bitcrusher,
          bits: (ring 1,2,3).tick,
        sample_rate: 44000 do
          with_fx :slicer, phase: 0.25, pulse_width: 0.125 do
            12.times do
              play 66,
                amp: 1,
                attack: 0.0125,
                sustain: (line 0.125, 0.25, steps: 16).tick,
                decay: 0, release: 0.125,
                wave: 1,
                res: (ring 0.5, 0.5, 0.5, 0.25).tick
              play 79,
                amp: 1,
                attack: 0.0125,
                sustain: (line 0.125, 0.25, steps: 16).tick,
                decay: 0, release: 0.125,
                wave: 1,
                res: (ring 0.5, 0.5, 0.5, 0.25).tick
              play 33,                 amp: 1,
                attack: 0.125,
                sustain: (line 0.125, 0.25, steps: 16).tick,
                decay: 0, release: 0.125,
                wave: 1,
                res: (ring 0.5, 0.5, 0.5, 0.25).tick
              
              sleep 0.25
            end
          end
        end
      end
    end
  end
end
