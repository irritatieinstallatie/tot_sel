live_loop :G2022_02_17_079C do
  use_bpm 100
  n1 = 27
  n2 = 28
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: rrand_i(1,6),
    sample_rate: 44000 do
      20.times do
        play n1,
          amp: 3,
          attack: 0.05,
          sustain: 0.25,
          release: 0.05,
          wave: 2
        play n1+0.25, amp: 2,
          attack: 0.05,
          sustain: 0.25,
          release: 0.05,
          wave: 2
        play n1+0.5,
          amp: rrand_i(0,2),
          attack: 0.05,
          sustain: 0.25,
          release: 0.05,
          wave: 2
        play n2,
          amp: 2.0,
          attack: 0.25,
          sustain: 0.25,
          release: 0.25,
          wave: 2
        sleep (stretch [0.5],10,[0.25],10).tick
      end
    end
  end
end
