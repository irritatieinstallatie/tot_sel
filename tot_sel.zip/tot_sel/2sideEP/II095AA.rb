live_loop :II095AA do
  use_bpm 100
  n1 = 71
  n2 = 68
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: 7,
    sample_rate: 33000 do
      with_fx :gverb, dry: 4.5, room: 33 do
        30.times do
          play n1,
            amp: 1,
            attack: 0.01,
            sustain: 0.5,
            # sustain: (stretch [0.25],4,[1],1).reflect.tick,
            release: 0.01,
            wave: 2
          play n1+0.25, amp: 1,
            attack: 0.01,
            sustain: 0.5,
            #          sustain: (stretch [0.25],20,[1],1,[0.5],6).reflect.tick,
            release: 0.01,
            wave: 2
          play n1+0.5,
            amp: 1,
            attack: 0.01,
            sustain: 0.5,
            #          sustain: (stretch [0.5],4,[1],6,[0.25],4,[0.5],4).reflect.tick,
            release: 0.01,
            wave: 0
          play n2,
            amp: 1,
            attack: 0.01,
            sustain: 0.5,
            #sustain: (stretch [0.5],2,[1],6,[0.25],4).reflect.tick,
            release: 0.01,
            wave: 2
          sleep 2
          #        sleep (ring 1, 0.5, 0.25,0.5).tick
        end
      end
    end
  end
end
