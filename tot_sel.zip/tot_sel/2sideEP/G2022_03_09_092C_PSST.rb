live_loop :G2022_03_09_092A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :bitcrusher, bits: 3 do
      with_fx :panslicer, phase: 0.125, pulse_width: 0.25,
      mix: (stretch [1],10,[0.5], 1).reflect.tick do
        play 38.5, amp: 1,
          attack: 0.125,
          sustain: 1,
          release: 0.125,
          wave: 2
        play 39, amp: 1,
          attack: 0.125,
          sustain: 1,
          release: 0.125,
          wave: 2
        play 39.5, amp: 1,
          attack: 0.125,
          sustain: 1,
          release: 0.125,
          wave: 2
        sleep 0.5
      end
    end
  end
end
