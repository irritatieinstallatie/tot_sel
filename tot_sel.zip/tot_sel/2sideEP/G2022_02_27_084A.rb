live_loop :G2022_02_27_084A do
  use_bpm 100
  with_synth :mod_saw do
    with_fx :gverb,
      spread: 0.5,
      dry: 0.5,
    room: 50 do
      with_fx :slicer,
      phase: (stretch [0.125],3,
              [0.25],3,
              [0.5],3,
              [0.99],3
      ).tick,
      pulse_width: (stretch [0.125],3,
                    [0.25],3,
                    [0.5],3,
                    [0.99],3
      ).tick do
        3.times do
          play 28,
            amp: rrand_i(0,4),
            sustain: 3
          play 57,
            amp: rrand_i(0,4),
            sustain: 3
          play 66,
            amp: rrand_i(0,4),
            sustain: 3
          sleep 1
        end
        3.times do
          play 57,
            amp: rrand_i(0,4),
            sustain: 3
          play 38,
            amp: rrand_i(0,4),
            sustain: 3
          play 65,
            amp: rrand_i(0,4),
            sustain: 3
          sleep 1
        end
        3.times do
          play rrand(54, 62),
            amp: rrand_i(0,4),
            sustain: 9
          play rrand(37,41),
            amp: rrand_i(0,4),
            sustain: 9
          play rrand(61,66),
            amp: rrand_i(0,4),
            sustain: 9
          sleep 7
        end
      end
    end
  end
end
