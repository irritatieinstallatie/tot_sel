live_loop :II094AA1 do
  use_bpm 100
  n1 = 28
  n2 = 29
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: 7,
    sample_rate: 33000 do
      20.times do
        play n1,
          amp: 2,
          attack: 0.05,
          sustain: 0.5,
          release: 0.05,
          wave: 2
        play n1+0.25,
          amp: 2,
          attack: 0.05,
          sustain: 0.5,
          release: 0.05,
          wave: 2
        play n1+0.5,
          amp: 2,
          attack: 0.05,
          sustain: 0.5,
          release: 0.05,
          wave: 2
        play n2,
          amp: 4.0,
          attack: 0.00125,
          sustain: 0.675,
          release: 0.125,
          wave: 2
        sleep 0.5
      end
    end
  end
end
