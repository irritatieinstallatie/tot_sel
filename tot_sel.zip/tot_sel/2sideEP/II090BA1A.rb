live_loop :II090BA1 do
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: 3.75,
    sample_rate: 33000 do
      with_fx :level, amp: 0.675 do
        4.times  do
          play 30,
            amp: 1,
            attack: 0.01,
            attack_level: 0,
            decay: 0.125,
            decay_level: 0.5,
            sustain: 0.25,
            sustain_level: 1,
            release: 0.001,
            res: 0.005,
            wave: 2
          play 25,
            amp: 1,
            attack: 0.1,
            attack_level: 0,
            decay: 0.125,
            decay_level: 0.5,
            sustain: 0.125,
            sustain_level: 1,
            release: 0.001,
            res: 0.005,
            wave: 2
          sleep 0.25
        end
      end
    end
  end
end
