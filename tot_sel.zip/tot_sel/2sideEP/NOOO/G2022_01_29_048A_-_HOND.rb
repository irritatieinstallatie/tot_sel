live_loop :G2022_01_29_048A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, spread: 0.125, dry: 3, room: 33 do
      with_fx :slicer, phase: 0.5, pulse_width: 0.5 do
        play 33, amp: 4,
          attack: 0,
          sustain: 0.25,
          release: 0,
          wave: 2,
          res: 0.95
        play (ring 32.8,33.2).tick,
          amp: (ring 0,2,3,2,3,2,0).tick,
          attack: 0.25,
          sustain: 0.25,
          release: 0.25,
          wave: 2,
          res: 0.95
        sleep 0.5
      end
    end
  end
end
