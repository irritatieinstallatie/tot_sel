
live_loop :G2022_01_09_023A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :slicer do
      with_fx :gverb, spread: 0.25, dry: 1, room: 77 do
        play 33, amp: 1, wave: 1,
          attack: 0.05
        play 55, wave: 1, amp: 1,
          attack: 0.05
        sleep 1
      end
    end
  end
end
live_loop :G2022_01_09_023B do
  use_bpm 100
  with_synth :tb303 do
    play 33, amp: 1,
      wave: 1,
      attack: 0.05, attack_level: 1,
      sustain: 0.25
    play 55, amp: 1,
      wave: 1,
      attack: 0.05, attack_level: 0.25,
      sustain: 0.125
    sleep 0.25
  end
end
