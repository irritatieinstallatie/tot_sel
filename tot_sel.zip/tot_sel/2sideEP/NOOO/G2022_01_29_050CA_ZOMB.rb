live_loop :G2022_01_29_050CA do
  use_bpm 100
  n1 = 28
  with_synth :tb303 do
    20.times do
      play n1+1, amp: 1,# (ring 0.5,2).tick,
        attack: 0.5,
        #     sustain: (ring 0.125,0.25,0.25,0.25).tick,
        release: 0.75,
        res: 0.5,
        wave: 2
      play n1, amp: 1,#(ring 0,2).tick,
        attack: 0.5,
        #      sustain: (ring 0.125,0.25,0.25,0.25).tick,
        release: 0.75,
        res: 0.5,
        wave: 2
      play n1+0.25, amp: 4,#(stretch [1],2,[3],4).tick,
        attack: 0.5,
        #       sustain: (ring 0.125,0.25,0.25,0.25).tick,
        release: 0.75,
        res: 0.5,
        wave: 2
      play n1+0.5, amp: 1,# (ring 4,0).tick,
        attack: 0.5,
        #        sustain: (ring 0.125,0.25,0.25,0.25).tick,
        release: 0.75,
        res: 0.5,
        wave: 2
      #sleep 0.75
      sleep (stretch [0.75], 10, [0.5], 4, [0.75], 2).tick
    end
  end
end
