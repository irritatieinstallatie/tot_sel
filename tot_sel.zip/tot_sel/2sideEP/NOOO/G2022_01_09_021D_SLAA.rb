live_loop :G2022_01_09_021D do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, dry: 5, spread: 0.5, room: 66 do
      with_fx :slicer, phase: 0.99,
      pulse_width: 0.99 do
        1.times do
          play 26, amp: 2,
            attack: 0.09,
            attack_level: 0.99,
            decay: 0.99,
            sustain: 0.99,
            release: 0.09
          sleep 0.125
          play 37, amp: 2,
            attack: 0.09,
            attack_level: 0.99,
            decay: 0.99,
            sustain: 0.99,
            release: 0.09
          sleep 0.125
          play 50, amp: 2,
            attack: 0.09,
            attack_level: 0.99,
            decay: 0.99,
            sustain: 0.99,
            release: 0.09
          sleep 1
        end
      end
    end
  end
end
