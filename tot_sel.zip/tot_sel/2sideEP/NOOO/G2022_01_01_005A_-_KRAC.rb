live_loop :G2022_01_01_005B do
  fy = rrand_i(38,44)
  use_random_seed 111
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, room: 22 do
      with_fx :slicer,
      pulse_width: 0.25, phase: 0.125 do
        play (ring fy+0.5, fy+1, fy+1.5), amp: 2,
          attack: 0.175, sustain: 1
        sleep (stretch [1], 8, [0.5], 1).tick
      end
    end
  end
end
