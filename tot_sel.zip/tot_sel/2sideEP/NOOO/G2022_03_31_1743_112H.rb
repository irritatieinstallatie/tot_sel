live_loop :G2022_03_27_112H do
  set_volume! 1.0
  n2 = 22
  s2 = 0.05
  use_bpm 100
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: rrand_i(1,4),
    sample_rate: 44000 do
      with_fx :panslicer,
        phase: 0.125,
      pulse_width: 0.275 do
        with_fx :gverb, spread: 0.5, dry: (ring 1,2).tick, room: 44 do
          12.times do
            play n2+4, amp: 1,
              attack: 0.0125,
              sustain: s2,
              release: 0.25,
              res: 0.05,
              wave: (stretch [2],2,[1],2).tick
            play n2+5, amp: 1,
              attack: 0.0125,
              sustain: s2,
              release: 0.25,
              res: 0.05,
              wave: (stretch [1],2,[2],2).tick
            play n2+6, amp: 1,
              attack: 0.0125,
              sustain: s2,
              release: 0.25,
              res: 0.05,
              wave: (stretch [2],2,[1],2).tick
            play n2+7, amp: 1,
              attack: 0.0125,
              sustain: s2,
              release: 0.25,
              res: 0.05,
              wave: (stretch [1],2,[2],2).tick
            sleep 0.25
            #sleep (stretch [0.125], 4, [0.25], 4).tick
          end
        end
      end
    end
  end
end
