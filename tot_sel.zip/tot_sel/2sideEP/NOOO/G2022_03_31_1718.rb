live_loop :G2022_03_31_1718 do
  with_synth :tb303 do
    with_fx :gverb, spread: 0.125, dry: 4, room: 33  do
      play 30, amp: 1,
        attack: 0.001,
        decay: 0.0,
        sustain: 1,
        release: 0.001
      play 50, amp: 1,
        attack: 0.001,
        decay: 0.0,
        sustain: 1,
        release: 0.001
      sleep 1
    end
  end
end
