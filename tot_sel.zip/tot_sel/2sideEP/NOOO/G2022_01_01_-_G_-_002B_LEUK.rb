set_volume! 1

live_loop :G2022_01_01_002A do
  use_bpm 60
  with_synth :tb303 do
    play 20,
      amp: 2
    if one_in(5)
      sleep 0.5
    else
      sleep 0.25
    end
  end
end
live_loop :G2022_01_01_002B do
  use_bpm 60
  with_synth :pulse do
    #    with_fx :slicer, phase: 0.99, pulse_width: 0.5 do
    play 32,
      amp: 4
    if one_in(20)
      sleep 0.5
    else
      sleep 0.25
    end
    sleep rrand_i(0,0.125)
    #   end
  end
end
