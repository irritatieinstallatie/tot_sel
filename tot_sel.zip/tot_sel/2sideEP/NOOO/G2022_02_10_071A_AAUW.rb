live_loop :G2022_02_10_071A do
  n01 = rrand_i(10,20)
  use_random_seed 101
  use_bpm 100
  with_synth :tb303 do
    with_fx :slicer, phase: 0.25, pulse_width: 0.25 do
      n01.times do
        play 55, amp: 1,
          attack: 0,
          decay: 0,
          sustain: 0.25,
          release: 0,
          res: 0.5,
          wave: 2
        play 58, #amp: rrand(0,1),
          sustain: 0.25,
          res: 0.5,
          wave: 2
        sleep 0.125
        play 66, #amp: rrand(0.01,0.99),
          sustain: 0.25,
          res: 0.5,
          wave: 2
        play 66.5, #amp: rrand(0.01,0.99),
          sustain: 0.25,
          res: 0.5,
          wave: 2
        play 67, #amp: rrand(0,1),
          sustain: 0.25,
          res: 0.5,
          wave: 2
        sleep 0.125
        play 78, #amp: rrand(0.01,0.99),
          sustain: 0.125,
          res: 0.5,
          wave: 2
        sleep 0.125*rrand_i(1,2)
    end    end
  end
end



