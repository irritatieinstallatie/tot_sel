live_loop :G2022_02_07_066C do
  use_bpm 100
  with_synth :tb303 do
    with_fx :slicer,
      phase: 0.25,
    pulse_width: rrand(0.125,0.99) do
      6.times do
        play 33, amp: 2,
          attack: 0.001,
          sustain: 0.5,
          release: 0.001,
          wave: 2
        play 69, amp: 1,
          attack: 0.001,
          sustain: 0.25,
          release: 0.001,
          wave: 2
        play 44, amp: 2,
          attack: 0.001,
          sustain: 0.5,
          release: 0.001,
          wave: 2
        sleep 0.25
      end
    end
  end
end
live_loop :G2022_02_07_066D do
  use_bpm 100
  with_synth :piano do
    with_fx :slicer,
      phase: 0.5,
    pulse_width: 0.5 do
      play 33, amp: 2,
        attack: 0.001,
        sustain: 0.25,
        release: 0.001,
        wave: 2,
        vel: 0.5,
        hard: 0.75
      play 69, amp: 1,
        attack: 0.001,
        sustain: 0.25,
        release: 0.001,
        wave: 2,
        vel: 0.5,
        hard: 0.75
      play 77, amp: 1,
        attack: 0.001,
        sustain: 0.25,
        release: 0.001,
        wave: 2,
        vel: 0.5,
        hard: 0.75
      play 44, amp: 1,
        attack: 0.001,
        sustain: 0.25,
        release: 0.001,
        wave: 2,
        vel: 0.5,
        hard: 0.75
      sleep 0.5
    end
  end
end
