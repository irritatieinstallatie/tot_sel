#2019_01_22_002AC

use_bpm 120

use_random_seed rrand(0,101)
set_volume! 1





live_loop :hcja do
  
  with_synth :tb303 do
    with_fx :reverb, room: 0.5, mix: 0.25 do
      with_fx :gverb, spread: 0.5, dry: 4, room: 55 do
        with_fx :krush do
          with_fx :nrbpf, centre: 60, res: 0.5 do
            with_fx :ixi_techno, phase: 4, res: 0.5, mix: 0.5 do
              28.times do
                play (ring 36, 59, 47), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                play (ring 34, 81, 46), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                play (ring 31, 49, 47), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                sleep 0.25
              end
              14.times do
                play (ring rrand(33,37), rrand(59, 63), rrand(47,55)), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                play (ring 33, 81, 96), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                play (ring 53, 59, 57), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                sleep 0.25#sleep (ring 0.25, 0.75).tick
              end
              21.times do
                play (ring 33, 59, 47), amp: 1, attack: 0.05, sustain: 0.125, release: 0.05
                play (ring 33, 81, 96), amp: 1, attack: 0.05, sustain: 0.125, release: 0.05
                #          play 44, sustain: 0.75
                play (ring 53, 59, 57), amp: 1, attack: 0.05, sustain: 0.125, release: 0.05
                sleep 0.25
              end
              7.times do
                play (ring 33, 59, 47), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                play (ring 53, 39, 57, 81, 96), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                sleep 0.5
              end
              14.times do
                play (ring 53, 39, 57, 81, 96), amp: 1, attack: 0.05, sustain: 0.5, release: 0.05
                
                sleep (ring 0.25, 0.25, 0.5, 0.5).stretch(2).tick
              end
            end
          end
        end
      end
    end
  end
end





live_loop :hcjb do
  use_bpm 60
  with_synth :hoover do
    with_fx :reverb, room: 0.5 do
      with_fx :gverb, spread: 0.5, dry: 4, room: 55 do
        with_fx :nrbpf, centre: 75, res: 0.5 do
          with_fx :bitcrusher, bits: rrand_i(1,6), sample_rate: 44000 do
            with_fx :flanger do
              if one_in(2)
                35.times do
                  play (ring 36, 59, 47, 34, 81, 46), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                  play (ring 31, 49, 47), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                  sleep 0.25
                end
              else
                35.times do
                  play (ring 36, 59, 47, 34, 81, 46), amp: 7, attack: 0.05, sustain: 0.25, release: 0.05
                  play (ring 31, 49, 47), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                  sleep 0.25
                end
              end
              21.times do
                play (ring rrand(33,37), rrand(59, 63), rrand(47,55)), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                play (ring 33, 81, 96), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                play (ring 53, 59, 57), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                sleep 0.5
              end
              if one_in(2)
                35.times do
                  play (ring 43, 59, 47), amp: 1, attack: 0.05, sustain: 0.125, release: 0.05
                  play (ring 53, 51, 76), amp: 1, attack: 0.05, sustain: 0.125, release: 0.05
                  play (ring 53, 59, 57), amp: 1, attack: 0.05, sustain: 0.125, release: 0.05
                  sleep 0.25
                end
              else
                35.times do
                  play (ring 33, 59, 47), amp: 1, attack: 0.05, sustain: 0.125, release: 0.05
                  play (ring 33, 81, 96), amp: 1, attack: 0.05, sustain: 0.125, release: 0.05
                  #play 66
                  play (ring 53, 59, 57), amp: 1, attack: 0.05, sustain: 0.125, release: 0.05
                  sleep 0.25
                end
              end
              if one_in(2)
                21.times do
                  play (ring 33, 59, 47), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                  play (ring 33, 81, 96), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                  play (ring 53, 59, 57), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                  sleep 0.5
                end
              else
                21.times do
                  play (ring 33, 59, 47), amp: 4, attack: 0.05, sustain: 0.25, release: 0.05
                  play (ring 33, 81, 96), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                  play (ring 53, 59, 57), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                  sleep 0.5
                end
              end
            end
          end
        end
      end
    end
  end
end





