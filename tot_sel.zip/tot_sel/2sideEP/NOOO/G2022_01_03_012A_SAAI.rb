live_loop :G2022_01_03_012A do
  with_synth :dark_ambience do
    with_fx :slicer, pulse_width: 0.25, phase: 0.125 do
      with_fx :gverb, spread: 1.0, dry: 5.0, room: 77 do
        play 69, amp: 6,
          sustain: 0.025
        play 54, amp: 6,
          sustain: 0.025
        sleep (stretch
               [1.0],4,
               [1.0],4).tick
      end
    end
  end
end
