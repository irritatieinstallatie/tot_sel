live_loop :G2022_01_01_001 do
  g0053 = rrand_i(4,6)
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, room: 77 do
      g0053.times do
        16.times do
          with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
            with_fx :bitcrusher, bits: 16, sample_rate: 44000 do
              play 69, amp: 2,
                attack: 0.0125, release: 0.125
            end
            play (ring 50, 55, 60), amp: rrand(5,10)
          end
          sleep 0.25
        end
        #        sleep rrand(0,1)
      end
      #     sleep rrand(1,2)
    end
  end
end
