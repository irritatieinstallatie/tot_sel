live_loop :G2022_02_06_061A do
  
  #  use_random_seed 101
  use_bpm 100
  with_synth :tb303 do
    with_fx :slicer, phase: 0.25, pulse_width: 0.125 do
      play 58, amp: rrand(0,1),
        wave: 2
      play 66, amp: rrand(0.01,0.99),
        wave: 2
      play 67, amp: rrand(0,1),
        wave: 2
      play 78, amp: rrand(0.01,0.99),
        wave: 2
      sleep (stretch [0.25],rrand_i(1,10),
             [0.5],rrand_i(1,10)
             ).tick
    end
  end
end

live_loop :G2022_02_06_061B do
  
  use_bpm 100
  with_synth :tb303 do
    with_fx :slicer, phase: 0.25, pulse_width: 0.25 do
      play 48, amp: rrand_i(1,2),
        attack: 0,
        decay: 0,
        sustain: 0.5,
        release: 0,
        wave: 2
      sleep 0.5
    end
  end
end






