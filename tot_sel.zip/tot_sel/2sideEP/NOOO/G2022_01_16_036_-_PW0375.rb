live_loop :G2022_01_16_036A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :slicer, phase: 0.99, pulse_width: 0.5 do
      with_fx :gverb, spread: 0.5, dry: 0.25, room: 55 do
        play 33, amp: 1,
          attack: 0.01,
          decay: 0.75,
          res: rrand(0,1)
        sleep (stretch [0.5],6, [0.75],4, [1],1, [0.75],5).tick
      end
    end
  end
end
