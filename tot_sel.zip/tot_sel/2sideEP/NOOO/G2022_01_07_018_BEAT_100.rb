
live_loop :G2022_01_07_018A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, room: 77 do
      with_fx :slicer,
        pulse_width: 0.5,
      phase: 0.5 do #0.125 -> 0.5
        play (ring 40.5, 41, 41.5), amp: 4,
          attack: 0.01, attack_level: 3,
          decay: 0.25, release: 0.125,
          sustain: 0.25, sustain_level: 0.5
        sleep 0.5
      end
    end
  end
end
