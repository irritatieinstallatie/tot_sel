live_loop :G2022_03_27_105A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, spread: 0.5, dry: 5, room: 22 do
      12.times do
        play 44,
          amp: 1,
          attack: 0.001,
          sustain: (ring 1,0.5).tick,
          release: 0.001,
          res: 0.9,
          wave: 1
        play 33,
          amp: 1,
          attack: 0.001,
          sustain: (ring 0.5,1).tick,
          release: 0.001,
          res: 0.9,
          wave: 2
        sleep 0.25
      end
      sleep rrand(0.125,1)
    end
  end
end
