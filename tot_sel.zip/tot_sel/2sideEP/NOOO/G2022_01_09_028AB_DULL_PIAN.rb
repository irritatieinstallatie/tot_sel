live_loop :G2022_01_09_028A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :ixi_techno, phase: 5 do
      with_fx :slicer, phase: 0.5, pulse_width: 0.25 do
        play 77, amp: 6,
          attack: 0.05, sustain: 1, release: 0.05
        sleep 1
      end
    end
  end
end
live_loop :G2022_01_09_028B do
  use_bpm 100
  with_synth :piano do
    with_fx :gverb, dry: 5, spread: 0.5, room: 55 do
      with_fx :ixi_techno, phase: 5 do
        with_fx :slicer, phase: 0.5, pulse_width: 0.125 do
          play 77, amp: 6,
            attack: 0.05, sustain: 0.25, release: 0.05,
            vel: 0.5
          play 78, amp: 0,
            attack: 0.05, sustain: 1, release: 0.05,
            vel: 0.5
          sleep 1
        end
      end
    end
  end
end
