live_loop :G2022_01_09_024A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :slicer, phase: 0.5, pulse_width: 0.25 do
      play 49, amp: 1,
        res: 0.75,
        attack: 0.05,
        decay: 0.0,
        sustain: 0.5,
        release: 0.05
      sleep 0.25
    end
  end
end


live_loop :G2022_01_09_024B do
  use_bpm 100
  with_synth :piano do
    with_fx :slicer, phase: 0.5, pulse_width: 0.25 do
      play 49, amp: 2,
        res: 0.75,
        attack: 0.01,
        decay: 0.0,
        sustain: 0.25,
        release: 0.01
      sleep (stretch [0.25], 12, [0.5],8).tick
    end
  end
end
