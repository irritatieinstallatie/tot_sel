live_loop :G2022_02_08_067A do
  use_bpm 100
  with_synth :tb303 do
    20.times do
      play 29.125,
        amp: (ring 2,2,2,1).tick,
        attack: 0.005,
        release: 0.75,
        res: (line 0.1, 0.8, steps: 8).mirror.tick,
        wave: 2
      play 29,
        amp: (line 0,2, steps: 10).mirror.tick,
        attack: 0.005,
        release: 0.75,
        res: (line 0.1, 0.8, steps: 8).mirror.tick,
        wave: 2
      play 29.25,
        amp: (ring 2,1,2,2).tick,
        attack: 0.005,
        release: 0.75,
        res: (line 0.1, 0.8, steps: 8).mirror.tick,
        wave: 2
      play 29.5,
        amp: (line 0,2, steps: 10).mirror.tick,
        attack: 0.005,
        release: 0.75,
        res: (line 0.1, 0.8, steps: 8).mirror.tick,
        wave: 2
      sleep 0.25
    end
  end
end
