

live_loop :G2022_01_01_004 do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, room: 22 do
      with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
        play 20, amp: 14,
          res: 0.1,
          attack: 0.125, sustain: 0.125
        sleep (stretch [1.0], 32, [0.5], 8).tick
      end
    end
  end
end
