live_loop :G2022_01_20_40A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, spread: 0.9, dry: 2, room: 55 do
      with_fx :slicer,
      pulse_width: 0.5, phase: 0.25 do
        play (ring 40.5, 41, 41.5), amp: 8,
          attack: 0.2,
          release: 0.02,
          sustain: 0.5#(ring 0.125,0.25,0.5,0.75,1).tick
        sleep (stretch [0.75], 8, [0.25], 2).tick
      end
    end
  end
end


live_loop :G2022_01_20_40B do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, spread: 0.9, dry: 2, room: 55 do
      with_fx :slicer,
      pulse_width: 0.5, phase: 0.5 do
        play (ring 40.5, 41, 41.5), amp: 8,
          attack: 0.5,
          decay: 0.5,
          release: 0.5,
          sustain: 0.5
        sleep 1
      end
    end
  end
end
