live_loop :G2022_02_04_060D_F do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, room: 22 do
      with_fx :krush,
      res: (line 0.1, 0.9, steps: 8).mirror.tick do
        with_fx :nrbpf,
        centre: (stretch [75],8, [100],8).tick, res: 0.5 do
          with_fx :ixi_techno, phase: 1,
            res: (stretch [0.99],2,
                  [0.9],8,
                  [0.5],8
                  ).mirror.tick,
          mix: 0.5 do
            12.times do
              play (ring 33, 59, 47), amp: 1,
                attack: 0.05, sustain: 0.25, release: 0.05
              play (ring 53, 39, 57, 81, 96).tick, amp: 1,
                attack: 0.05, sustain: 0.25, release: 0.05
              sleep 0.25
            end
          end
        end
      end
    end
  end
end
