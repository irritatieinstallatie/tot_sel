live_loop :G2022_01_03_013B do
  with_synth :tb303 do
    with_fx :slicer,
    pulse_width: 0.25, phase: 0.125 do
      play 46, amp: 2,
        attack: 0.01,
        decay: 0.0,
        sustain: 0.25,
        release: 0.125
      sleep 0.25
    end
  end
end
