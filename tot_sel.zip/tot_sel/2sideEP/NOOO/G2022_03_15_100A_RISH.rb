live_loop :G2022_03_15_100A do
  set_volume! 1
  use_bpm 100
  n1 = (line 28, 29, steps: 10).choose
  n2 = 29
  sr1 = (ring 1,2).tick*
  (ring 0.125,0.25,0.25,0.25).mirror.tick
  rl2 = 2
  lr1 = (ring 4,8,4).mirror.tick
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: (line 2,5, steps: 100).choose,
    sample_rate: 44000 do
      lr1.times do
        play n1, amp: (ring 0,4).tick,
          attack: 0.05,
          sustain: sr1,
          release: 0.05,
          wave: 2
        play n1+0.25, amp: 3,
          attack: 0.05,
          sustain: sr1,
          release: 0.05,
          wave: 2
        play n1+0.5,
          amp: (ring 12,0).tick,
          attack: 0.05,
          sustain: sr1,
          release: 0.05,
          wave: 2
        play n2,
          amp: 1,
          attack: 0.05,
          sustain: sr1,
          release: 0.05,
          wave: 2
        sleep rl2*0.125
      end
    end
  end
end
