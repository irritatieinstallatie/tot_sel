live_loop :G2022_01_18_39AB02 do
  use_bpm 100
  na0 = 0
  na025 = 0.25
  na05 = 0.5
  na1 = 1
  na2 = rrand_i(0,1)
  na3 = rrand(0,1)
  with_synth :piano do
    with_fx :slicer, phase: 0.5, pulse_width: 0.25 do
      play (ring 60, 50, 30, 11), amp: na0,
        attack: 0.05, sustain: 0.05, release: 0.0125,
        vel: 1
      play (ring 30,31,32,33), amp: na0,
        attack: 0.05, sustain: 0.05, release: 0.0125,
        vel: rrand(0.125,1)
      sleep 0.25
    end
  end
end
live_loop :G2022_01_18_39B do
  use_bpm 100
  na0 = 0
  na025 = 0.25
  na05 = 0.5
  na1 = 1
  na2 = rrand_i(0,1)
  na3 = rrand(0,0.5)
  with_synth :piano do
    with_fx :slicer, phase: 0.5, pulse_width: 0.25 do
      play (ring 60, 50, 30, 11), amp: na0,
        attack: 0.05, sustain: 0.25, release: 0.0125,
        vel: 1
      play (ring 30,31,32,33), amp: na0,
        attack: 0.0125, sustain: 0.25, release: 0.0125,
        vel: rrand(0.125,1)
      sleep 0.125
    end
  end
  sleep (stretch [0],(ring 8,12).tick,
         [0.125],4,
         [rrand_i(0,1)],1,
         [0.25],4,
         [rrand_i(0,1)],1,
         [0.125],4,
         [rrand_i(0,1)],1
         ).tick
end
