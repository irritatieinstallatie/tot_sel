live_loop :G2022_02_08_068A do
  with_synth :hoover do
    with_fx :gverb, room: 21 do
      with_fx :nrbpf,
        mix: (line 0,1, steps: 12).mirror.tick,
      res: 0.25 do
        with_fx :bitcrusher,
          bits: rrand_i(2,8),
        sample_rate: rrand_i(200, 4400) do
          24.times do
            play 46,
              amp: 1,
              attack: 0.05, sustain: 0.125, release: 0.05
            play 38,
              amp: (line 0,1, steps: 12).mirror.tick,
              attack: 0.05, sustain: 0.25, release: 0.05
            play 47,
              amp: 1,
              attack: 0.05, sustain: 0.25, release: 0.05
            sleep 0.25
          end
        end
      end
    end
  end
end


