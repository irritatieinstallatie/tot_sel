live_loop :G2022_01_09_021A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, dry: 1, spread: 1, room: 54 do
      with_fx :ixi_techno,
        phase: 1,
      phase_offset: 0.25, res: 0.2 do
        with_fx :slicer, phase: 0.25, pulse_width: 0.25 do
          8.times do
            play 26, amp: 3,
              attack: 0.01,
              attack_level: 0.125,
              decay: 0,
              sustain: 0.25,
              release: 0.1
            play 70, amp: 3,
              attack: 0.01,
              attack_level: 0.125,
              decay: 0,
              sustain: 0.25,
              release: 0.1
            play 69, amp: 3,
              attack: 0.01,
              attack_level: 0.125,
              decay: 0,
              sustain: 0.25,
              release: 0.1
            sleep 0.25
          end
        end
      end
    end
  end
end
