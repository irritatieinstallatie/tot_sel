live_loop :G2022_01_04_014a do
  xo0 = rrand_i(4,12)
  use_bpm 100
  with_synth :tb303 do
    xo0.times do
      play 62, attack: 0.01, sustain: 0.05, release: 0.01
      sleep 0.25
    end
    sleep rrand_i(0,1)
  end
end
live_loop :G2022_01_04_014b do
  xo1 = rrand_i(4,12)
  use_bpm 100
  with_synth :tb303 do
    xo1.times do
      play 50,
        attack: 0.01, sustain: 0.05, release: 0.01
      sleep 0.25
    end
    sleep rrand_i(0,1)
  end
end
live_loop :G2022_01_04_014c do
  xo0 = rrand_i(12,20)
  use_bpm 100
  with_synth :tb303 do
    xo0.times do
      play 50, amp: rrand(0,1),
        attack: 0.01, sustain: 0.05, release: 0.01
      sleep 0.25
    end
    sleep rrand_i(0,1)
  end
end
live_loop :G2022_01_04_014d do
  xo1 = rrand_i(12,20)
  use_bpm 100
  with_synth :tb303 do
    xo1.times do
      play (ring 90, 95, 100).tick, amp: rrand(0,1),
        attack: 0.01, sustain: 0.05, release: 0.01
      sleep 0.25
    end
    sleep rrand_i(0,1)
  end
end
