set_volume! 1

live_loop :G2022_01_07_017E do
  use_random_seed (ring 7,6,5,4,3,2,1).tick
  use_bpm 100
  n0 = rrand_i(4,8)
  t0r0 = rrand_i(15,35)
  with_synth :tb303 do
    with_fx :reverb, room: 0.5, mix: 0.5 do
      with_fx :gverb, spread: 0.75, dry: 1, room: 55 do
        with_fx :slicer, phase: 0.375, pulse_width: 0.375 do
          with_fx :bitcrusher,
          bits: (ring 1,1,1,1,2,3,4,5).choose do
            n0.times do
              play 70, amp: 1,
                attack: 0.01, attack_level: 0.75,
                sustain: 0.0125, decay: 0.0125,
                decay_level: 0.0125,release: 0.05
              play 71, amp: 1,
                attack: 0.01, attack_level: 0.75,
                sustain: 0.0125, decay: 0.0125,
                decay_level: 0.0125,release: 0.05
              sleep 0.25
            end
          end
        end
      end
    end
  end
  
end
#G2019_01_22_001C


stevig = rrand_i(4,21)
stevig2 = rrand_i(20,40)





live_loop :hcja do
  use_bpm 80
  
  with_synth :tb303 do
    with_fx :level, amp: 0.5 do
      with_fx :gverb, spread: 0.5, dry: 2, room: 77 do
        with_fx :krush, res: 0.25 do
          with_fx :nrbpf, centre: (ring 100, 75, 50).tick, res: 0.5 do
            with_fx :ixi_techno, phase: 4, res: 0.5, mix: 0.5 do
              4.times do
                stevig2.times do
                  play (ring 36, 59, 47).tick, amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                  play (ring 34, 81, 46), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                  play (ring 31, 49, 47), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                  sleep 0.125
                end
                
                stevig.times do
                  play (ring rrand(33,37), rrand(59, 63), rrand(47,55)).choose, amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                  play (ring 33, 81, 96), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                  play (ring 53, 59, 57), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                  sleep 0.25
                end
                
                stevig.times do
                  play (ring 33, 59, 47).choose, amp: 1, attack: 0.05, sustain: 0.125, release: 0.05
                  play (ring 33, 81, 96), amp: 1, attack: 0.05, sustain: 0.125, release: 0.05
                  play (ring 53, 59, 57), amp: 1, attack: 0.05, sustain: 0.125, release: 0.05
                  sleep 0.125
                end
                
                stevig.times do
                  play (ring 33, 59, 47), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                  play (ring 53, 39, 57, 81, 96).tick, amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
                  sleep 0.25
                end
                
                stevig.times do
                  play (ring 53, 39, 57, 81, 96), amp: 1, attack: 0.05, sustain: 0.5, release: 0.05
                  
                  sleep (ring 0.125, 0.125, 0.25, 0.25).stretch(2).tick
                end
                
              end
            end
            sleep rrand(1,2)
          end
        end
      end
    end
  end
  
  
  
  
end




