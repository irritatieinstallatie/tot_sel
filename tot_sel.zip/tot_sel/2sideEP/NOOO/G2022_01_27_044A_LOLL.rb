live_loop :G2022_01_27_044A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :slicer, phase: 0.5,
    pulse_width: 0.25 do
      play 44, amp: rrand_i(0,2),
        attack: 0.01,
        sustain: 0.075,
        release: 0.01
      play (stretch [51],12,[52],1,[53],1,[54],1).tick,
        amp: rrand_i(0,1),
        attack: 0.01,
        sustain: 0.075,
        release: 0.01
      sleep 0.125
    end
  end
end
