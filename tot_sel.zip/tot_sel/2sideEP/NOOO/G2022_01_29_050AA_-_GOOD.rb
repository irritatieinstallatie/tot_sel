live_loop :G2022_01_29_050A do
  use_bpm 100
  with_synth :tb303 do
    play 33, amp: 1,
      sustain: 1,
      wave: 2
    play 33.5, amp: 1,
      sustain: 1,
      wave: 2
    sleep 0.5 # 0.1 > 1
  end
end
