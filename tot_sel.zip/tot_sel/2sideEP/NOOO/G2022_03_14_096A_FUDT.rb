live_loop :G2022_03_14_096A do
  use_bpm 100
  with_synth :tb303 do
    20.times do
      play 59,
        amp: 1,
        attack: 0.05,
        sustain: 0.125,
        release: 0.05,
        res: 0.125,
        wave: 2
      play 54,
        amp: 1,
        attack: 0.05,
        sustain: 0.125,
        release: 0.05,
        res: 0.5,
        wave: 2
      sleep (stretch [0.25], rrand_i(5,10),
             [0.25],rrand_i(5,10)
             ).tick
    end
  end
end
