live_loop :G2022_01_09_020A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, dry: 1, spread: 1, room: 54 do
      play 26, amp: 1,
        attack: 0.01,
        attack_level: 0.125,
        decay: 0,
        sustain: 0.75,
        release: 0.01
      sleep (stretch [0.25],24,
             [0.5],2,
             [0.25],12,
             [0.5],2).tick
    end
  end
end
