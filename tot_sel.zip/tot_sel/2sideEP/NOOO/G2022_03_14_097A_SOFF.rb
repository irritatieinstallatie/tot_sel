live_loop :G2022_03_14_097A do
  use_bpm 100
  n1o = (line 0.001, 0.125, steps: 10).mirror.tick
  with_synth :tb303 do
    with_fx :gverb, spread: 0.5, dry: 4, room: 44 do
      with_fx :slicer, phase: 0.25, pulse_width: 0.25 do
        20.times do
          play 59,
            amp: 1,
            attack: n1o,
            sustain: 0.5,
            release: n1o,
            wave: 2
          play 52,
            amp: 1,
            attack: n1o,
            sustain: 0.5,
            release: n1o,
            wave: 2
          play 53,
            amp: (line 0,1, steps: 10).choose,
            attack: n1o,
            sustain: 0.25,
            release: n1o,
            wave: 2
          play 54,
            amp: 1,
            attack: n1o,
            sustain: 0.25,
            release: n1o,
            wave: 2
          sleep (stretch [0.25], (ring 1,10).tick,
                 [0.5], (ring 1,10).tick).tick
        end
      end
    end
  end
end
