live_loop :G2022_02_10_069D do
  use_bpm 100
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: 2,
    sample_rate: rrand_i(333,55555) do
      8.times do
        play 36,
          attack: 0.001,
          sustain: rrand(0,1),
          release: 0.001,
          res: 0.1,
          wave: 2
        play 48,
          attack: 0.001,
          sustain: rrand(0,1),
          release: 0.001,
          res: 0.1,
          wave: 2
        sleep 0.25
      end
    end
  end
end
