live_loop :G2022_01_16_033A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :ixi_techno, phase: 6 do
      with_fx :slicer, phase: 0.99, pulse_width: 0.75 do
        play 27, amp: 4,
          attack: 0.01, attack_level: 0.5,
          sustain: 0.25,
          release: 0.75
        play (ring 26,28), amp: 8,
          attack: 0.01, attack_level: 0.5,
          sustain: 0.25,
          release: 0.75
        sleep 1
      end
    end
  end
end
