live_loop :G2022_02_13_076A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :bitcrusher, bits: rrand_i(2,6),
      sample_rate: rrand_i(4400, 44000),
    mix: 0.75 do
      with_fx :gverb, spread: 0.5, dry: 3, room: 55 do
        with_fx :slicer, phase: 0.25, pulse_width: 0.125 do
          12.times do
            play 39, amp: 1,
              attack: 0.001,
              sustain: 0.25*(stretch [0.5],2,[0.125],10).tick,
              decay: 0.05,
              release: 0.001,
              wave: (ring 2,1,2,2,1,0,0,0,1).choose
            play 34, amp: 1,
              attack: 0.01,
              sustain: 0.25*(stretch [0.5],2,[0.125],10).reflect.tick,
              decay: 0.05,
              release: 0.01,
              wave:  (ring 2,1,2,2,1,2,0,2,1).choose
            sleep 0.25
          end
        end
      end
    end
  end
end
