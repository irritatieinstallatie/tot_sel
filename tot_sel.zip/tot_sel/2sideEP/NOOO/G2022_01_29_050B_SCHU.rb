live_loop :G2022_01_29_050B do
  use_bpm 100
  with_synth :tb303 do
    with_fx :normaliser, mix: 0.75, level: 1 do
      play 34, amp: 4,
        attack: 0.01,
        sustain: 0.4,
        release: 0.5,
        wave: 2
      play 33, amp: 4,
        attack: 0.01,
        sustain: 0.4,
        release: 0.5,
        wave: 2
      play (ring 33.2, 33.4), amp: 4,
        attack: 0.01,
        sustain: 0.4,
        release: 0.5,
        wave: 2
      sleep (stretch [0.25], rrand_i(6,12),
             [0.5],rrand_i(6,12),
             [1],rrand_i(6,12)
             ).tick
    end
  end
end
