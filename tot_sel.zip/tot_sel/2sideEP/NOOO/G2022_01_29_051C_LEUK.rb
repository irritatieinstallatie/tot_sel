live_loop :G2022_01_29_051C do
  use_bpm 100
  n0x0 = 25
  lx0 = 4*rrand_i(1,2)
  with_synth :tb303 do
    lx0.times do
      play n0x0-0.1, amp: 8,
        attack: 0.001,
        sustain: (ring 0.25, 0.5).stretch(2).tick,
        release: 0.01, wave: 1
      play n0x0, amp: 8,
        attack: 0.001,
        sustain: (stretch [0.5],rrand_i(8,12),
                  #             [0.175],2,
                  [0.25],4
                  ).tick,
        release: 0.01, wave: 1
      play n0x0+0.1, amp: 8,
        attack: 0.001,
        sustain: (ring 0.25, 0.5).stretch(2).tick,
        release: 0.01,
        wave: 1
      sleep (stretch [0.5],rrand_i(8,12),
             #             [0.175],2,
             [0.25],4
             ).tick
    end
  end
end
