live_loop :G2022_01_10_29B do
  use_bpm 100
  n0x0 = rrand_i(30,36)
  lx0 = rrand_i(12,24)
  with_synth :tb303 do
    lx0.times do
      play n0x0-0.2, amp: 4, attack: 0.001, sustain: 2, release: 0.001, res: (line 0.49, 0.99, steps: 10).choose, wave: 1
      play n0x0, amp: 4, attack: 0.001, sustain: 2, release: 0.001, res: (line 0.49, 0.99, steps: 10).choose, wave: 1
      play n0x0+0.2, amp: 4, attack: 0.001, sustain: 2, release: 0.001, res: (line 0.49, 0.99, steps: 10).choose, wave: 1
      sleep 1
    end
  end
end
