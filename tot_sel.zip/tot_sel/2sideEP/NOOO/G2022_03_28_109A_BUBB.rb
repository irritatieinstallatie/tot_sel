live_loop :G2022_03_28_109A do
  set_volume! 1
  use_bpm 100
  nx0 = 30
  with_synth :tb303 do
    with_fx :gverb, spread: 0.05, dry: 10, room: 44, mix: 1 do
      with_fx :slicer, phase: 0.125, pulse_width: 0.5 do
        8.times do
          play nx0, amp: 1,
            attack: 0.25,
            sustain: (stretch [0.25], rrand_i(1,2), [0.125],rrand_i(1,2)).tick,
            release: 0.25,
            #            res: (line 0.5, 0.99, steps: 4).mirror.tick,
            wave: 1
          play nx0+2, amp: 1,
            attack: 0.125,
            sustain: (stretch [0.125], rrand_i(1,2), [0.25],rrand_i(1,2)).tick,
            release: 0.25,
            res: 0.09,
            wave: 2
          play nx0+(ring 1,2).tick, amp: 1,
            attack: 0.25,
            sustain: (stretch [0.25], rrand_i(1,2), [0.125],rrand_i(1,2)).tick,
            release: 0.25,
            res: 0.09,
            wave: 2
          play nx0+6, amp: 1,
            attack: 0.125,
            sustain: (stretch [0.125], rrand_i(1,2), [0.25], rrand_i(1,2)).tick,
            release: 0.25,
            res: 0.09,
            wave: 2
          sleep 0.5
        end
      end
    end
  end
end
