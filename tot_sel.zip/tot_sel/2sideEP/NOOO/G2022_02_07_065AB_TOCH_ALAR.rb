live_loop :G2022_02_07_065A do
  use_random_seed 104
  use_bpm 100
  t0 = rrand_i(20,120)
  with_synth :dark_ambience do
    with_fx :slicer, phase: 0.5, pulse_width: 0.25 do
      play t0, amp: 32,
        attack: 0.001,
        attack_level: 0.75,
        sustain: 0.5,
        decay: 0.25,
        decay_level: 0.0125,
        release: 0.001
      sleep (stretch [0.125], rrand_i(24,48),
             [1],1,
             [0.125], rrand_i(24,48),
             [1],1
             ).tick
    end
  end
end
live_loop :G2022_02_07_065B do
  use_bpm 100
  with_synth :dark_ambience do
    with_fx :slicer, phase: 1, pulse_width: 0.375 do
      play 69, amp: 32,
        attack: 0.0025,
        attack_level: 0.75,
        sustain: 0.375,
        decay: 0.99,
        decay_level: 0.0125,
        release: 0.0025
      sleep 0.5
    end
  end
end
