live_loop :G2022_01_09_034A do
  #  use_random_seed 104
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, dry: 1, spread: 1, room: 54 do
      with_fx :ixi_techno,
        phase: rrand(0.01,0.99),
        phase_offset: rrand(0.01,0.99),
      res: rrand(0.01,0.99) do
        with_fx :slicer,
          phase: 0.25,
        pulse_width: 0.125 do
          32.times do
            play 27, amp: 4,
              attack: 0.01,
              attack_level: 0.125,
              decay: 0,
              sustain: 0.25,
              release: 0.1
            play 54, amp: 4,
              attack: 0.01,
              attack_level: 0.125,
              decay: 0,
              sustain: 0.25,
              release: 0.1
            sleep 0.5
          end
          sleep rrand_i(0,2)
        end
      end
    end
  end
end
