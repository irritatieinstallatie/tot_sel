live_loop :G2022_05_08_124A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, spread: 0.75, dry: 5, room: 88 do
      with_fx :slicer,
      pulse_width: 0.125, phase: 0.25 do
        6.times do
          play (ring 60.5, 61, 61.5), amp: 1,
            attack: 0.175, sustain: 1
          play (ring 50.5, 51, 51.5), amp: 2,
            attack: 0.175, sustain: 1
          sleep 0.5
        end
      end
    end
  end
end
