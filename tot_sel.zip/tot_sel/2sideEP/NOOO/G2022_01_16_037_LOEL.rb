live_loop :G2022_01_16_037A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :slicer, phase: 0.99, pulse_width: 0.5 do
      with_fx :gverb, spread: 1, dry: rrand(0,1), room: 55 do
        play 33, amp: 1,
          attack: 0.01,
          decay: 0.75,
          res: rrand(0,1)
        sleep (stretch
               [0.5],5,
               [0.75],5,
               [1],1,
               [0.75],4,
               [1],1,
               [0.75],3,
               [0.5],2,
               [1],1,
               [0.75],2
               ).tick
      end
    end
  end
end
