live_loop :G2022_01_20_041A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :ixi_techno, phase: 15 do
      with_fx :slicer,
        phase: 0.125,
      pulse_width: 0.25 do
        play 44,
          amp: 1,
          sustain: 0.7
        play 43,
          amp: 1,
          sustain: 0.7
        sleep 1
      end
    end
  end
end
