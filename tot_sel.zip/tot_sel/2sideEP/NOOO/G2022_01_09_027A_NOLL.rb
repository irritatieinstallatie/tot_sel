live_loop :G2022_01_09_027A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :slicer, phase: 0.5, pulse_width: 0.5 do
      play 40, amp: rrand_i(0,2),
        attack: 0.05, sustain: 0.25, release: 0.125
      play 41, amp: rrand_i(0,2),
        attack: 0.05, sustain: 0.25, release: 0.125
      play 42, amp: rrand_i(0,2),
        attack: 0.05, sustain: 0.25, release: 0.125
      play 43, amp: rrand_i(0,2),
        attack: 0.05, sustain: 0.25, release: 0.125
      sleep 0.25
    end
  end
end

