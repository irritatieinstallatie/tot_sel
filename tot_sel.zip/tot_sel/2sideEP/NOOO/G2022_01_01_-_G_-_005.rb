live_loop :G2022_01_01_005 do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, room: 22 do
      with_fx :slicer, pulse_width: 0.5, phase: 0.25 do
        play (ring 40.5, 41, 41.5), amp: 4,
          attack: 0.175, sustain: 1
        sleep (stretch [1], 8, [0.5], 1).tick
      end
    end
  end
end
