
live_loop :G2022_01_07_019A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, room: 77 do
      with_fx :slicer,
        phase: 0.5,
      pulse_width: 0.5 do
        play 25, amp: 5,
          attack: 0.05,
          decay: 0.75,
          sustain: 0.75,
          release: 0.05
        sleep 1
      end
    end
  end
end
