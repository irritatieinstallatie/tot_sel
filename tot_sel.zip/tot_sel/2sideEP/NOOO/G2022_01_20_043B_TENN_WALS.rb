live_loop :G2022_01_16_035B do
  n048 = rrand_i(4,8)
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, spread: 0.75, dry: 5, room: 54 do
      with_fx :ixi_techno,
        phase: 0.375,
        phase_offset: 0.5,
      res: 0.2 do
        with_fx :slicer,
          phase: 0.25,
        pulse_width: 0.125 do
          n048.times do
            play 27, amp: 4,
              attack: 0.01, attack_level: 1,
              sustain: 0.125,
              release: 0.75
            sleep 1
          end
        end
        sleep 1
      end
    end
  end
end
