live_loop :G2022_01_03_013E do
  use_bpm 100
  with_synth :tb303 do
    with_fx :slicer,
    pulse_width: 0.5, phase: 0.25 do
      play 40, amp: 1,
        attack: 0.001,
        decay: 0.0,
        sustain: (line 0.4, 0.99, steps: 100).mirror.tick,
        release: 0.001
      sleep 0.1
    end
  end
end
live_loop :G2022_01_03_013F do
  use_bpm 100
  with_synth :tb303 do
    with_fx :slicer,
    pulse_width: 0.5, phase: 0.25 do
      play 46, amp: 2,
        attack: 0.001,
        decay: 0.0,
        sustain: (line 0.4, 0.99, steps: 100).mirror.tick,
        release: 0.001,
        wave: 2
      play 44, amp: 2,
        attack: 0.001,
        decay: 0.0,
        sustain: (line 0.4, 0.99, steps: 100).mirror.tick,
        release: 0.001,
        wave: 1
      sleep 0.5
    end
  end
end
