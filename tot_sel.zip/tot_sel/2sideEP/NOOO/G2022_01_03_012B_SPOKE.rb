live_loop :G2022_01_03_012B do
  use_bpm 100
  with_synth :dark_ambience do
    with_fx :slicer, pulse_width: 0.5, phase: 0.25 do
      with_fx :gverb,
        spread: 0.25, dry: 2.5,
      room: 77 do
        play 69, amp: 6,
          sustain: 0.025
        play 54, amp: 6,
          sustain: 0.025
        sleep (stretch
               [0.75],4,
               [0.75],4).tick
      end
    end
  end
end
