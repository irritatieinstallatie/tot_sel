live_loop :G2022_01_01_004A do
  use_bpm 120
  with_synth :tb303 do
    with_fx :gverb, room: 77 do
      with_fx :bitcrusher,
        bits: 4,
      sample_rate: 4400 do
        with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
          16.times do
            play (line 69, 79, steps: 10).choose,
              amp: 0.5,
              attack: 0.0125,
              sustain: (line 0.125, 0.25, steps: 16).tick,
              decay: 0, release: 0.125,
              wave: 1,
              res: (ring 0.5, 0.5, 0.5, 0.25).tick
            #play 33, sustain: 0.0675
            sleep 0.25
          end
          sleep (ring 0,0.25,0.5,1).tick
        end
      end
    end
  end
end
