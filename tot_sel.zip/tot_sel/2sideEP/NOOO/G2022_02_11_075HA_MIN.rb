live_loop :G2022_02_11_075HA do
  set_volume! 1
  use_bpm 100
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: rrand_i(1,5),
    sample_rate: 44000 do
      16.times do
        play 28, amp: (ring 0,4).tick,
          attack: 0.05,
          sustain: (stretch [0.25],6,
                    [1],rrand_i(2,8),
                    [0.125],2).mirror.tick,
          release: 0.05,
          res: 0.75,
          wave: 2
        play 29,
          amp: 1,
          attack: 0.05,
          sustain: (stretch [0.25],6,
                    [0.125],rrand_i(2,8),
                    [2],2).mirror.tick,
          release: 0.05,
          res: 0.75,
          wave: 2
        sleep 0.25
      end
    end
  end
end
