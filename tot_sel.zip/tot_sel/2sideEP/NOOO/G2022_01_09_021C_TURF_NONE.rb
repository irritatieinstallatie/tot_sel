

live_loop :G2022_01_09_021C do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, dry: 1, spread: 0.5, room: 66 do
      with_fx :slicer, phase: 0.5,
      pulse_width: (line 0.125, 0.99, steps: 10).mirror.tick do
        10.times do
          play 26, amp: 2,
            attack: 0.99,
            attack_level: 0.99,
            decay: 0.99,
            sustain: 0.99,
            release: 0.99
          sleep 0.125
          play 37, amp: 2,
            attack: 0.99,
            attack_level: 0.99,
            decay: 0.99,
            sustain: 0.99,
            release: 0.01
          sleep 0.125
          play 50, amp: 2,
            attack: 0.99,
            attack_level: 0.99,
            decay: 0.99,
            sustain: 0.99,
            release: 0.99
          sleep 0.125
        end
      end
    end
  end
end
