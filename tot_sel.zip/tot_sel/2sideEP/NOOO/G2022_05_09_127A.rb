



live_loop :X2019_11_15A01 do
  set_volume! 1
  use_bpm 60
  with_synth :dark_ambience do
    with_fx :slicer, phase: 0.5, pulse_width: 0.25 do
      with_fx :nrbpf do
        play (line 21, 77, steps: 10).mirror.look, amp: 2, sustain: 0.125
        sleep 0.125
      end
      #sleep (ring 0,0,0,0,0,0,0,0,0,1).tick
    end
  end
end
