live_loop :G2022_01_29_048A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, mix: 0.5,
      spread: 0.125, dry: 3,
    room: 66 do
      with_fx :slicer, phase: 0.5, pulse_width: 0.5 do
        play 32.1, amp: 4,
          attack: 0,
          sustain: 0.25,
          release: 0,
          wave: 2,
          res: 0.95
        sleep 0.5
      end
    end
  end
end
