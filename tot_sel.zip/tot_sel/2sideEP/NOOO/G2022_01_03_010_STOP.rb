

live_loop :G2022_01_03_010 do
  use_bpm 100
  with_synth :tb303 do
    with_fx :bitcrusher, bits: 2, sample_rate: 44000 do
      with_fx :slicer, pulse_width: 0.5, phase: 0.25 do
        play 37, amp: 4,
          attack: 0.05,
          sustain: 0.25
        sleep 1
      end
    end
  end
end
