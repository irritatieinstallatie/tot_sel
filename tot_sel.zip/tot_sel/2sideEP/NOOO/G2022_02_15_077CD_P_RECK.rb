live_loop :G2022_02_15_077C do
  na0 = rrand(1,2)
  with_synth :tb303 do
    20.times do
      play 33, amp: na0,
        attack: 0.001,
        sustain: 0.5,
        release: 0.001,
        res: 0.75,
        wave: 2
      play 45, amp: na0,
        attack: 0.001,
        sustain: 0.5,
        release: 0.001,
        res: 0.75,
        wave: 0
      sleep (stretch [0.25], 4, [0.125],rrand_i(1,4),[0.5],rrand_i(1,6)).mirror.tick
    end
  end
end
live_loop :G2022_02_15_077D do
  with_synth :piano do
    with_fx :bitcrusher, bits: rrand_i(3,7), sample_rate: 44000 do
      with_fx :krush, mix: 0.0,
      res: 0.25 do
        20.times do
          play 31, amp: 2,
            sustain: 0.5,
            vel: 0.25,
            hard: 0.5
          play 34, amp: 2,
            sustain: 0.5,
            vel: 0.25,
            hard: 0.5
          sleep (stretch [0.25], 4, [0.125],rrand_i(1,4),[0.5],rrand_i(1,6)).mirror.tick
        end
      end
    end
  end
end
