live_loop :G2022_02_03_054A do
  use_bpm 100
  n0 = rrand_i(1,16)
  with_synth :tb303 do
    with_fx :gverb, spread: 0.75, dry: 2, room: 55 do
      with_fx :slicer,
        phase: 0.25,
      pulse_width: 0.25 do#rrand(0.75,0.99) do
        n0.times do
          play 41.75, amp: 1,
            attack: 0.001,
            sustain: 0.125,
            release: 0.001,
            wave: 0
          play 41.5, amp: 1,
            attack: 0.001,
            sustain: 0.125,
            release: 0.001,
            wave: 0
          play 42,
            attack: 0.001,
            sustain: 0.125,
            release: 0.001,
            amp: 1,
            wave: 2
          sleep 0.25
        end
      end
    end
  end
end
