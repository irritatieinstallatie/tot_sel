live_loop :G2022_01_05_016A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, room: 77 do
      #      8.times do
      with_fx :slicer, phase: 0.5, pulse_width: 0.125  do
        8.times do
          play (ring 69,79), amp: 1
          play 29, amp: 1,
            attack: 0.0125,
            sustain: 0.125,
            release: 0.125,
            wave: 1,
            res: 0.125
          sleep 0.75
        end
      end
      #    end
    end
  end
end
live_loop :G2022_01_05_016B do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, room: 77 do
      with_fx :slicer, phase: 0.5, pulse_width: 0.25  do
        #          8.times do
        play 30, amp: 0.5,
          attack: 0.01,
          sustain: 0.125,
          release: 0.125,
          wave: 1,
          res: 0.125
        sleep 0.75
        #         end
      end
    end
  end
end
