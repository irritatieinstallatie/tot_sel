live_loop :G2022_01_03_013A do
  with_synth :tb303 do
    with_fx :slicer,
    pulse_width: 0.25, phase: 0.125 do
      play 50, amp: 2,
        attack: 0.001,
        decay: 0.0,
        sustain: 0.25,
        release: 0.001
      sleep 1
    end
  end
end
