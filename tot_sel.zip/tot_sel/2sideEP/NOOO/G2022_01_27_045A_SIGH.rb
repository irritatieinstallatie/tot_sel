live_loop :G2022_01_27_045A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :rbpf, centre: 80, res: 0.5, mix: 0.125 do
      with_fx :gverb, spread: 0.125,
      dry: 5, room: 55 do
        with_fx :slicer, phase: 0.75, pulse_width: 0.75 do
          play 46,
            sustain: 0.25,
            release: 0.01,
            amp: 8
          play 29, amp: 8,
            attack: 0.1,
            decay: 0.1
          sleep (stretch [1.0], rrand_i(12,24), [2],2).tick
        end
      end
    end
  end
end
