live_loop :G2022_01_29_047A do
  use_bpm 100
  with_synth :tb303 do
    play 33, amp: 12,
      attack: 0,
      sustain: 1,
      release: 0,
      wave: 2,
      res: 0#(line 0
    sleep 0.125
    play (ring rrand(32.8,33),rrand(33,33.2)).tick, amp: rrand(3,4),
      attack: 0.01,
      sustain: 1.05,
      release: 0.15,
      wave: 2,
      res: 0.5
    sleep 1.125
  end
end
