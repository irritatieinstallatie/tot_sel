live_loop :G2022_01_09_021FA do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, dry: 1, spread: 0.9, room: 54 do
      with_fx :ixi_techno,
        phase: (ring 0.5, 0.75, 1).stretch(8).choose,
      phase_offset: 0.125, res: 0.5 do
        with_fx :slicer, phase: 0.75, pulse_width: 0.75 do
          8.times do
            play 26, amp: 4,
              attack: 0.01,
              attack_level: 0.125,
              decay: 0,
              sustain: 0.25,
              release: 0.1,
              wave: 1
            play 50, amp: 4,
              attack: 0.01,
              attack_level: 0.125,
              decay: 0,
              sustain: 0.25,
              release: 0.1,
              wave: 0
            play 25, amp: 4,
              attack: 0.01,
              attack_level: 0.125,
              decay: 0,
              sustain: 0.25,
              release: 0.1,
              wave: 2
            sleep 0.75
          end
        end
      end
    end
  end
end
