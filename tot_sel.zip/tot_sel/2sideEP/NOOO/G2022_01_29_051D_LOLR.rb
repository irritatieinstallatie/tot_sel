live_loop :G2022_01_29_051D do
  use_bpm 100
  n0x0 = 39
  lx0 = 4*rrand_i(1,2)
  with_synth :tb303 do
    lx0.times do
      play n0x0-0.1, amp: 4,
        attack: 0.001,
        sustain: 0.5,
        release: 0.001,
        pulse_width: 0.3,
        res: 0.2,
        wave: (ring 2,2,2,2,1,2,1,2).tick
      play n0x0, amp: 8,
        attack: 0.001,
        sustain: 0.3,
        release: 0.001,
        pulse_width: 0.3,
        res: 0.2,
        wave: 1
      play n0x0+0.1, amp: 4,
        attack: 0.001,
        sustain: 0.5,
        release: 0.001,
        pulse_width: 0.3,
        res: 0.2,
        wave: (ring 2,2,1,2,1,2,1,2).tick
      sleep 0.5
    end
    sleep rrand(0,0.875)
  end
end
