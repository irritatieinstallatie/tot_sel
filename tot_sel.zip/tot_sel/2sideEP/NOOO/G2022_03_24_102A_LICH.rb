live_loop :G2022_03_15_102A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, spread: 0.125, dry: (ring 2,8).tick, room: 44 do
      with_fx :slicer, phase: 0.125, pulse_width: 0.75 do
        with_fx :bitcrusher, bits: 3, sample_rate: 44000 do
          6.times do
            play 66,
              amp: 1,
              attack: 0.125,
              sustain: 0.5,
              release: 0.125
            play 67,
              amp: 1,
              attack: 0.125,
              sustain: 0.5,
              release: 0.125
            play 68,
              amp: 1,
              attack: 0.0125,
              sustain: 0.05,
              decay: (ring 0.125, 0.5).tick,
              release: 0.0125
            sleep 0.5
          end
        end
      end
    end
  end
end
