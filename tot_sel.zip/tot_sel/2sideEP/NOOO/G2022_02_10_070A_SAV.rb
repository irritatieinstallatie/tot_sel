live_loop :G2022_02_10_070A do
use_bpm 60
  with_synth :tb303 do
    play 20,
      amp: 1,
      sustain: 0.25,
      res: 0.5,
      wave: 2
    play 30,
      amp: 1,
      sustain: 0.25,
      res: 0.9,
      wave: 2
    play 40,
      amp: 1,
      sustain: 0.25,
      res: 0.5,
      wave: 0
    sleep 0.5
  end
end
