live_loop :G2022_01_28_046A do
  n01r = rrand_i(1,10)
  use_bpm 100
  with_synth :tb303 do
    n01r.times do
      play 33, amp: 12,
        attack: 0.5,
        sustain: (line 0.125, 0.5, steps: 12).mirror.choose,
        release: 0.5,
        wave: 2,
        res: (line 0, 0.99, steps: 12).mirror.choose
      sleep 0.3
    end
    sleep rrand(0, 0.75)
  end
end
