live_loop :G2022_01_09_026A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, dry: 0.75, spread: 0.125, room: 66 do
      play 79, amp: 1,
        attack: 0.01, sustain: 0.125, release: 0.01
      sleep 1
    end
  end
end
live_loop :G2022_01_09_026B do
  use_bpm 100
  with_synth :piano do
    with_fx :gverb, dry: 0.75, spread: 0.125, room: 66 do
      play 80, amp: 2,
        attack: 0.01, sustain: 0.125, release: 0.01
      sleep 1
    end
  end
end
