live_loop :G2022_02_04_058A do
  use_random_seed (ring 106,101,106,104,106,103,106,104).tick
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb,
      dry: 5,
      spread: 0.1,
    room: 55 do
      play 31, amp: 2,
        attack: 0.05,
        sustain: 0.125,
        release: 0.25,
        res: 0.1,
        wave: 2
      with_fx :slicer,
        phase: 0.5,
      pulse_width: 0.125 do
        play rrand_i(60,80), amp: 3,
          attack: 0.05,
          sustain: 0.25,
          release: 0.25,
          res: 0.1
        play (line 44, 45, steps: 10).mirror.tick,
          amp: (line 1,3, steps: 10).mirror.tick,
          attack: 0.001,
          sustain: 0.25,
          release: 0.001,
          res: 0.9,
          wave: 2
        sleep 0.75
      end
    end
  end
end
live_loop :G2022_02_04_058B do
  use_random_seed (ring 106,101,106,104,106,103,106,104).tick
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, dry: 5, spread: 0.1, room: 55 do
      play 31, amp: rrand_i(0,3),
        attack: 0.05,
        sustain: 0.125,
        release: 0.25,
        res: 0.1,
        wave: 2
      with_fx :slicer, phase: 0.5, pulse_width: 0.125 do
        play rrand_i(60,80),
          amp: rrand_i(0,3),
          attack: 0.05,
          sustain: 0.25,
          release: 0.25,
          res: 0.1
        play (line 44, 45, steps: 10).mirror.tick,
          amp: (line 0,3, steps: 10).mirror.tick,
          attack: 0.001,
          sustain: 0.25,
          release: 0.001,
          res: 0.9,
          wave: 2
        sleep 0.75
      end
    end
  end
end
