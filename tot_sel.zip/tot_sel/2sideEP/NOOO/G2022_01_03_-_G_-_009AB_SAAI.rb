live_loop :G2022_01_03_009A do
  with_synth :piano do
    play (ring 60, 50, 40, 11), amp: 2,
      attack: 0.05, sustain: 0.25, release: 0.0125
    sleep 0.125
  end
  sleep (stretch [0],14,[1],2).tick
end
live_loop :G2022_01_03_009B do
  with_synth :tb303 do
    with_fx :slicer, pulse_width: 0.5, phase: 0.25 do
      play (ring 31, 40), amp: 2,
        attack: 0.05, sustain: 0.125, release: 0.0125
      play 21, amp: 2,
        attack: 0.05, sustain: 0.125, release: 0.0125
      sleep 0.125
    end
    sleep (stretch [0],15,[1],1).tick
  end
end
