live_loop :G2022_02_11_074A do
  use_bpm 120
  with_synth :tb303 do
    with_fx :gverb, room: 77 do
      10.times do
        with_fx :bitcrusher,
          bits: 3,
        sample_rate: rrand_i(2200,44000) do
          with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
            play 33,
              attack: 0.005,
              sustain: 0.5,
              decay: 0.125,
              release: 0.005,
              res: 0.25,
              wave: 0
            play 33,
              attack: 0.005,
              sustain: 0.25,
              decay: 0.125,
              release: 0.005,
              res: 0.25,
              wave: 2
            sleep 0.25
          end
        end
      end
    end
  end
end
