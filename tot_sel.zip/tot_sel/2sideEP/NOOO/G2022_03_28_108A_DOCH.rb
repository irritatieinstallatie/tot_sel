live_loop :G2022_03_28_108A do
  set_volume! 1
  use_bpm 100
  n0x = 26
  with_synth :tb303 do
    with_fx :slicer,
      phase: 0.25,
    pulse_width: 0.5 do
      with_fx :bitcrusher,
        bits: rrand_i(4,8),
      sample_rate: 8800 do
        5.times do
          play n0x,
            amp: 1,
            attack: 0.001,
            sustain: 2,
            release: 0.001,
            res: 0.5,
            wave: 0
          play n0x,
            amp: 1,
            attack: 0.001,
            sustain: 2,
            release: 0.001,
            res: 0.5,
            wave: 1
          play n0x,
            amp: 1,
            attack: 0.001,
            sustain: 2,
            release: 0.001,
            res: 0.5,
            wave: 2
          sleep 1
        end
      end
    end
  end
end
