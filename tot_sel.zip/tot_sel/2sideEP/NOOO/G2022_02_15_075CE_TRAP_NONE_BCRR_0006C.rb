live_loop :G2022_02_15_075CE_TRAP_NONE_BCRR_0006C do
  use_random_seed (ring 107, 101, 114, 115, 117, 121, 123, 124, 125, 126, 127, 128).choose
  use_bpm 100
  n1 = 24
  n2 = 29
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: rrand_i(2,6),
    sample_rate: rrand_i(4400, 44000) do
      with_fx :ixi_techno, phase: 4,
        cutoff_min: 75,
        cutoff_max: 100,
        mix: 0.5,
      res: 0.001 do
        40.times do
          play n1,
            amp: 2,
            attack: 0.05,
            sustain: (stretch [0.125],rrand_i(12,16),
                      [0.25], rrand_i(1,4),
                      [0.125],rrand_i(2,4)).mirror.tick,
            release: 0.05,
            wave: 2
          play n1+0.25, amp: 2,
            attack: 0.05,
            sustain: (stretch [0.125],rrand_i(12,16),
                      [0.25], rrand_i(1,4),
                      [0.5],rrand_i(2,4)).mirror.tick,
            release: 0.05,
            wave: 2
          play n1+0.5,
            amp: rrand_i(0,2),
            attack: 0.05,
            sustain: (stretch [0.125],rrand_i(12,16),
                      [0.25], rrand_i(1,4),
                      [0.5],rrand_i(2,4)).mirror.tick,
            release: 0.05,
            wave: 2
          play n2,
            amp: 1.0,
            attack: 0.05,
            sustain: 0.5*(stretch [0.5],8, [1],4).mirror.tick,
            release: 0.05,
            wave: 2
          sleep 0.5
        end
      end
    end
  end
end
