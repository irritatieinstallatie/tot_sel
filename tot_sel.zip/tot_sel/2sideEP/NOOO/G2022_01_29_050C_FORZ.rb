live_loop :G2022_01_29_050C do
  use_bpm 100
  n1 = 28
  with_synth :tb303 do
    10.times do
      play n1+1, amp: (ring 0.5,2).tick,
        attack: 0.5,
        sustain: (ring 0.125,0.25,0.25,0.25).tick,
        release: 0.75,
        res: 0.5,
        wave: 2
      play n1, amp: (ring 0,2).tick,
        attack: 0.5,
        sustain: (ring 0.125,0.25,0.25,0.25).tick,
        release: 0.75,
        res: 0.5,
        wave: 2
      play n1+0.25, amp: 4,#(stretch [1],2,[3],4).tick,
        attack: 0.5,
        sustain: (ring 0.125,0.25,0.25,0.25).tick,
        release: 0.75,
        res: 0.5,
        wave: 2
      play n1+0.5, amp: (ring 4,0).tick,
        attack: 0.5,
        sustain: (ring 0.125,0.25,0.25,0.25).tick,
        release: 0.75,
        res: 0.5,
        wave: 2
      sleep 0.75
    end
  end
end
