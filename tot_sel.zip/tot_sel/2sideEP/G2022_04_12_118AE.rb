live_loop :G2022_04_12_118AC do
  set_volume! 1
  use_bpm 100
  n0 = 27
  n1 = (line 28, 29, steps: 5).choose
  n2 = 29
  sr1 = (ring 0,1,1,1,2,2).tick*(ring 0.125,0.25,0.25,0.25).mirror.tick
  rl2 = (ring 0.5,2).tick
  lr1 = 8#(ring 2,4,8,2,4).tick
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: (line 2,5, steps: 100).choose,
    sample_rate: 44000 do
      lr1.times do
        play n0, amp: 1,
          attack: 0.05,
          sustain: sr1,
          release: 0.05,
          wave: 2
        play n1, amp: (ring 0,1.5).tick,
          attack: 0.05,
          sustain: sr1,
          release: 0.05,
          wave: 2
        play n1+0.25, amp: 1,
          attack: 0.05,
          sustain: sr1,
          release: 0.05,
          wave: 2
        play n1+0.5,
          amp: (ring 1.25,0).tick,
          attack: 0.05,
          sustain: sr1,
          release: 0.05,
          wave: 2
        play n2,
          amp: 1,
          attack: 0.05,
          sustain: sr1,
          release: 0.05,
          wave: 2
        sleep rl2*0.125
      end
      sleep rl2*0.125
    end
  end
end

