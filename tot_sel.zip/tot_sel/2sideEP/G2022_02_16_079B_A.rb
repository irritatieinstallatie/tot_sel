live_loop :G2022_02_16_079B_A do
  use_bpm 100
  n1 = 27
  n2 = 28
  with_synth :tb303 do
    with_fx :reverb, room: 0.55, mix: 0.25 do
      with_fx :bitcrusher,
        bits: 2.5,
      sample_rate: 44000 do
        12.times do
          play n1,
            amp: rrand_i(1,2),
            attack: 0.05,
            sustain: 0.125,
            release: 0.05,
            wave: 2
          play n1+0.25,
            amp: rrand_i(2,1),
            attack: 0.05,
            sustain: 0.25,
            release: 0.05,
            wave: 2
          play n1+0.5,
            amp: rrand_i(1,2),
            attack: 0.05,
            sustain: 0.25,
            release: 0.05,
            wave: 2
          play n2,
            amp: rrand_i(1,2),
            attack: 0.25,
            sustain: 0.25,
            release: 0.25,
            wave: 2
          sleep 0.25
        end
      end
    end
  end
end
