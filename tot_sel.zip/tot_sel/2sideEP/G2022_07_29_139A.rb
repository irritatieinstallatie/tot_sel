live_loop :G2022_07_29_139A do
  use_random_seed 101
  use_bpm 100
  n1 = rrand_i(12,24)
  with_synth :tb303 do
    with_fx :gverb, spread: 0.5, dry: 4, room: 44 do
      with_fx :krush,
      res: (line 0.1, 0.9, steps: 10).choose do
        with_fx :nrbpf,
          centre: (line 100, 75, steps: 25).choose,
        res: 0.125 do
          with_fx :ixi_techno, phase: (ring 2,8,32,128).tick,
            res: 0.05,
          mix: 0.5 do
            n1.times do
              play 33,
                amp: 1,
                attack: 0.05, sustain: 0.25, release: 0.05
              play 47,
                amp: 1,
                attack: 0.05, sustain: 0.25, release: 0.05
              play 59,
                amp: 1,
                attack: 0.05, sustain: 0.25, release: 0.05
              play (ring 53,39,57,81,96),
                amp: 0.25,
                attack: 0.05, sustain: 0.25, release: 0.05
              sleep 0.25
            end
          end
        end
      end
    end
  end
end
