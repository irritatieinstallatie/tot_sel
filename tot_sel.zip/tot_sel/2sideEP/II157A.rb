live_loop :II157A do
  set_volume! 1
  use_bpm 100
  n1 = 27
  n2 = 28
  rc10 = rrand_i(4,8)
  with_synth :tb303 do
    with_fx :reverb, room: 0.25, mix: 0.5 do
      with_fx :bitcrusher,
        bits: 4,
        #     bits: (ring 1,2,3).reflect.tick,
      sample_rate: 44000 do
        rc10.times do
          play n1,
            amp: 1,
            attack: 0.005,
            sustain: 0.5,
            release: 0.005,
            wave: 2
          play n1+0.25,
            amp: 1,
            attack: 0.005,
            sustain: 0.5,
            release: 0.005,
            wave: 2
          play n1+0.5,
            amp: 1,
            attack: 0.005,
            sustain: 0.5,
            release: 0.005,
            wave: 2
          play n2,
            amp: 1,
            attack: 0.005,
            sustain: 0.5,
            release: 0.005,
            wave: 2
          #wave: (ring 0,0,0,2).tick
          sleep 0.5
          #           sleep (ring 0.25, 0.5).mirror.tick
        end
      end
    end
  end
end
