live_loop :II131AA1 do
  use_bpm 100
  with_synth :blade do
    with_fx :gverb, spread: 0.5, dry: 5, room: 55 do
      100.times do
        play (ring 50, 55, 60, 65, 70, 75, 80, 85), amp: 4,
          attack_level: 0.025,
          attack: 0.05,
          sustain: 0.25,
          release: 0.05,
          vibrato_rate: 1,
          vibrato_depth: 0.15,
          vibrato_delay: 0.5,
          vibrato_onset: 0.1,
          env_curve: 1,
          cutoff: 130
        sleep 1
      end
    end
  end
end



