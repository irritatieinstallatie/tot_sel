live_loop :G2022_02_16_079A_A do
  use_bpm 100
  n1 = 24
  n2 = 29
  n3 = 30
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: 2,
    sample_rate: 44000 do
      with_fx :level, amp: 1 do
        24.times do
          play n1,
            amp: 1,
            attack: 0.05,
            sustain: 0.25,
            release: 0.05,
            wave: 2
          play n1+0.25,
            amp: rrand_i(1,0),
            attack: 0.05,
            sustain: 0.25,
            release: 0.05,
            wave: 2
          play n1+0.5,
            amp: rrand_i(0,1),
            attack: 0.05,
            sustain: 0.25,
            release: 0.05,
            wave: 2
          play n3,
            amp: 2,
            attack: 0.005,
            sustain: 0.375,
            release: 0.005,
            wave: 2
          #          sleep 0.25
          sleep (stretch [0.5],4,[0.25],20).tick
        end
      end
    end
  end
end
