live_loop :M2022_01_01_000A do
  use_bpm 120
  with_synth :piano do
    with_fx :gverb, room: 77 do
      with_fx :slicer,
        phase: 0.25, #0.5
      pulse_width: 0.5 do #0.25
        with_fx :nlpf, centre: 95 do
          10.times do
            play (ring 47, 52, 57).tick,
              amp: 2,
              attack: 0.0125,
              decay: 0, sustain: 2, release: 0.0125,
              hard: 0.75, vel: (ring 0.1, 0.2, 0.3, 0.4).choose
            play (ring 49, 54, 59).tick,
              amp: 2,
              attack: 0.0125,
              decay: 0, sustain: 2, release:
              0.0125, hard: 0.25, vel: (ring 0.1, 0.2, 0.3, 0.4).choose
            play (line (ring 40, 45, 50).tick, (ring 52, 57, 62).tick, steps: 10).choose,
              amp: 2,
              attack: 0.125,
              sustain: 0.5, release: 0.125,
              hard: 0.75, vel: (ring 0.1, 0.2, 0.3, 0.4).choose
            sleep 0.5 #0.25
          end
        end
      end
    end
  end
end
