live_loop :G2021_00_00_000_EX01A do
  use_bpm 60
  zvntg = rrand(10,77)
  with_synth :supersaw do
    with_fx :gverb, room: 77 do
      with_fx :slicer, phase: 0.25, pulse_width: 0.25 do
        3.times do
          20.times do
            play zvntg+7, attack: 0.25, release: 0.25, sustain: 1
            play zvntg+7.5, attack: 0.25, release: 0.25, sustain: 1
            play zvntg+8, attack: 0.25, release: 0.25, sustain: 1
            sleep (ring 0.125, 0.25, 0.125, 0.25, 0.125).tick
          end
        end
      end
    end
  end
end
live_loop :G2021_00_00_000_EX01B do
  use_bpm 60
  with_synth :dpulse do
    with_fx :gverb, room: 77 do
      with_fx :slicer, phase: (ring 0.25, 0.5, 0.125, 0.5, 0.125).tick, pulse_width: (ring 0.5, 0.5, 0.5, 0.5, 0.25).tick do
        20.times do
          play 27, attack: 0.25, release: 0.25, sustain: 1
          sleep (ring 0.125, 0.25, 0.125, 0.125, 0.25).tick
        end
      end
    end
  end
end
