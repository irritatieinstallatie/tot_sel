live_loop :II080AA1 do
  use_bpm 100
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: 3,
      sample_rate: 44000,
    cutoff: 100 do
      10.times do
        play 44,
          amp: 1,
          attack: 0.001,
          sustain: 0.5,
          release: 0.001,
          res: 0.125,
          wave: 2
        play 31,
          amp: 1,
          attack: 0.001,
          sustain: 0.5,
          release: 0.001,
          res: 0.25,
          wave: 2
        sleep 1.2
      end
    end
  end
end
