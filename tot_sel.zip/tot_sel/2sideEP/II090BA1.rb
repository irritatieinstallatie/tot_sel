live_loop :II090BA1 do
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: 3.75,
    sample_rate: 33000 do
      with_fx :level, amp: 0.675 do
        4.times  do
          play 30,
            amp: 3,
            attack: 0.01,
            sustain: 0.5,
            release: 0.01,
            res: 0.005,
            wave: 2
          play 25,
            amp: 3,
            attack: 0.1,
            sustain: 0.25,
            release: 0.1,
            res: 0.005,
            wave: 2
          sleep 2
        end
      end
    end
  end
end
