
live_loop :G2022_04_01_113CA2 do
  use_bpm 100
  with_synth :tb303 do
    with_fx :krush,
      res: (line 0.01, 0.75, steps: 20).choose,
    mix: (line 0.01, 0.75, steps: 20).choose do
      with_fx :nrbpf,
      centre: 70, res: 0.5 do
        with_fx :ixi_techno, phase: 4, res: 0.5, mix: 0.5 do
          with_fx :reverb, room: 0.4, mix: 0.5 do
            4.times do
              play (ring 33, 33, 33).tick, amp: (ring 1,2).tick,
                attack: 0.05, sustain: 0.25, release: 0.05
              play (ring 47, 47, 47).choose, amp: (ring 2,1).tick,
                attack: 0.05, sustain: 0.25, release: 0.05
              play (ring 59, 59, 59).look, amp: (ring 1,2).tick,
                attack: 0.05, sustain: 0.25, release: 0.05
              play (ring 53, 39, 57, 81, 96), amp: (ring 2,1).tick,
                attack: 0.05, sustain: 0.25, release: 0.05
              sleep 0.25
            end
          end
        end
      end
    end
  end
end

