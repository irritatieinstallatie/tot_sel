set_volume! 1

live_loop :II090BA1CA do
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: 4,
    sample_rate: 44000 do
      with_fx :slicer, phase: 0.5, pulse_width: 0.5 do
        with_fx :nrlpf, cutoff: 50 do
          with_fx :reverb, damp: 0.5, room: 0.75 do
            with_fx :gverb, spread: 0.4, dry: 4, room: 88 do
              4.times  do
                play 25,
                  amp: 1,
                  attack: 0.01,
                  sustain: 0.5,
                  release: 0.01,
                  res: 0.005,
                  wave: 2
                play 26,
                  amp: 1,
                  attack: 0.1,
                  sustain: 0.125,
                  release: 0.1,
                  res: 0.005,
                  wave: 2
                sleep 0.25
              end
            end
          end
        end
      end
    end
  end
end
