a11 = 2
set_volume! 0.9
a21 = 2
a22 = 1
zs00 = rrand_i(20, 30)
zs01 =  60
zs10 = rrand_i(20, 30)
zs11 =  70
evenwicht = rrand_i(1,4)
live_loop :eerstegraads do
  use_bpm 60
  #with_synth :chipbass do
  with_synth :mod_sine do
    with_fx :bitcrusher, bits: 4, sample_rate: 44000 do
      with_fx :slicer, phase: 0.125, pulse_width: 0.25 do
        play (ring zs00+8, zs00+9, zs00+9, zs00+9, zs00+9, zs00+9, zs00+9).tick,
          amp: a11,
          attack: 0.0125,
          sustain: 0.125,
          decay: 0.1,
          release: 0.125,
          wave: 1,
          res: (ring 0.5, 0.5, 0.95).tick
        
        play (ring zs01+9, zs01+9, zs01+9, zs01+9, zs01+9, zs01+9, zs01+9).tick,
          amp: a11,
          attack: 0.0125,
          sustain: 0.250,
          decay: 0.1,
          release: 0.125,
          wave: 1,
          res: (ring 0.5, 0.5, 0.95).tick
        play (ring 67, 67, 67, 67, 67, 67, 67).tick,
          amp: a11,
          attack: 0.0125,
          sustain: 0.250,
          decay: 0.1,
          release: 0.125,
          wave: 1,
          res: (ring 0.5, 0.5, 0.95).tick
        sleep (ring 0.5, 0.5, 0.5, 0.5, 0.5, 0.25, 0.125).stretch(1).tick
      end
      #s      end
    end
  end
  #  sleep 1
end

live_loop :tweedegraads do
  use_bpm 60
  #with_synth :mod_dsaw do
  with_synth :tb303 do
    #    with_fx :nrbpf, res: 0.9 do
    with_fx :bitcrusher, bits: 16, sample_rate: 44000 do
      with_fx :slicer, phase: (ring 0.25, 0.125).tick, pulse_width: (ring 0.5, 0.25).tick do
        play (ring zs00+8, zs00+9, zs00+8, zs00+9, zs00+9, zs00+9, zs00+9).tick,
          amp: a21,
          attack: 0.0125,
          sustain: 0.125,
          decay: 0.1,
          release: 0.125,
          wave: 1,
          res: (ring 0.5, 0.5, 0.95).tick
        play (ring zs01+9, zs01+9, zs01+9, zs01+9, zs01+9, zs01+9, zs01+9).tick,
          amp: a21,
          attack: 0.0125,
          sustain: 0.250,
          decay: 0.1,
          release: 0.125,
          wave: 1,
          res: (ring 0.5, 0.5, 0.95).tick
        play (ring 67, 67, 67, 67, 67, 67, 67).tick,
          amp: a22,
          attack: 0.0125,
          sustain: 0.250,
          decay: 0.1,
          release: 0.125,
          wave: 1,
          res: (ring 0.5, 0.5, 0.95).tick
        sleep (ring 0.5, 0.5, 0.5, 0.5, 0.5, 0.25, 0.125).stretch(1).tick
      end
    end
  end
  # end
  #end
  #  sleep 1
end

live_loop :G2022_03_11_093A do
  use_bpm 60
  nz0 = 35
  with_synth :tb303 do
    with_fx :gverb,
      spread: 0.5,
      dry: 3,
    room: 55 do
      10.times do
        play nz0+5, amp: 1,
          attack: 0.01,
          sustain: 0.5,
          release: 0.01,
          wave: 0
        play nz0+6, amp: 1,
          attack: 0.01,
          sustain: 0.5,
          release: 0.01,
          wave: 0
        play nz0+7, amp: 1,
          attack: 0.01,
          sustain: 0.5,
          release: 0.01,
          wave: 0
        play nz0+8, amp: 1,
          attack: 0.01,
          sustain: 0.5,
          release: 0.01,
          wave: 0
        play nz0+9, amp: 1,
          attack: 0.01,
          sustain: 0.5,
          release: 0.01,
          wave: 0
        sleep 0.5
      end
    end
  end
end
