live_loop :G2022_02_04_057A do
  use_random_seed (ring 106,101,106,104,106,103,106,104).tick
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, dry: 5, spread: 0.1, room: 55 do
      with_fx :slicer, phase: 0.5, pulse_width: 0.125 do
        play 77, amp: 1,
          attack: 0.05, sustain: 0.25, release: 0.25, res: 0.1
        play rrand_i(60,80),
          attack: 0.05, sustain: 0.25, release: 0.25, res: 0.1
        play 44,
          attack: 0.05, sustain: 0.25, release: 0.25, res: 0.1
        sleep 0.5
      end
    end
  end
end
