live_loop :G2022_01_02_007a do
  with_synth :tb303 do
    with_fx :slicer, phase: 0.5, pulse_width: 0.25 do
      play 22, sustain: 4
      sleep 0.25
    end
  end
end
live_loop :G2022_01_02_007b do
  with_synth :tb303 do
    with_fx :slicer, phase: 0.75, pulse_width: 0.5 do
      play 23, sustain: 2
      sleep 0.25
    end
  end
end
