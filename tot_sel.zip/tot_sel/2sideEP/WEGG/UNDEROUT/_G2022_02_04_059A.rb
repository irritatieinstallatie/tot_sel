

live_loop :G2022_02_04_059A do
  #  use_random_seed 101
  use_bpm 100
  with_synth :tb303 do
    with_fx :slicer,
      phase:
    (stretch
     [0.25],rrand_i(1,6),
     [0.5],rrand_i(1,6)
    ).tick,
    pulse_width: 0.125 do
      play 53,
        amp: 2,
        attack: 0.001,
        sustain: 0.5,
        release: 0.001,
        wave: 2
      play 54,
        amp: 2,
        attack: 0.001,
        sustain: 0.5,
        release: 0.001,
        wave: 2
      play (line 51,52, steps: 10).mirror.choose,
        amp: 2,
        attack: 0.001,
        sustain: 0.5,
        release: 0.001,
        wave: 2
      sleep 0.5
    end
  end
end
