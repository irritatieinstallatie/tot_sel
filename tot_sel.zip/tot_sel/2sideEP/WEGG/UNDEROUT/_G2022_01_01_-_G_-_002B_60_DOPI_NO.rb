endt = 60
live_loop :M2022_01_01_002A0 do
  with_synth :tb303 do
    with_fx :slicer, phase: 0.25, pulse_width: 0.25 do
      play endt+rrand(-0.25,0.25), amp: rrand(1,2), release: 1
    end
    if one_in(10)
      sleep 0.25
    else
      sleep 0.125
    end
  end
	sleep rrand_i(0,1)
end
live_loop :M2022_01_01_002A1 do
  with_synth :tb303 do
    play endt, amp: rrand(2,4), release: 0.25
    if one_in(10)
      sleep 0.5
    else
      sleep 0.25
    end
  end
	sleep rrand_i(0,1)
end
live_loop :M2022_01_01_002B0 do
  with_synth :mod_pulse do
    with_fx :gverb, room: 22 do
      play endt+rrand(-0.25,0.25), amp: rrand(0,1), sustain: 0.0125
    end
    if one_in(20)
      sleep 0.5
    else
      sleep 0.25
    end
    #  sleep rrand_i(0,1)
  end
end
live_loop :M2022_01_01_002B1 do
  with_synth :mod_pulse do
    with_fx :slicer, phase: 0.25, pulse_width: 0.25 do
      play endt,       amp: rrand(2,4)
    end
    if one_in(20)
      sleep 0.5
    else
      sleep 0.25
    end
    # sleep rrand_i(0,1)
  end
end
