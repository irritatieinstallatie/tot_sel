live_loop :G2022_01_02_006A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, room: 33 do
      with_fx :slicer, phase: 0.5, pulse_width: 0.25 do
        with_fx :bitcrusher do
          play (ring 50, 51), amp: 4, attack: 0.125, sustain: 0.125
          sleep (stretch [0.5], 6, [0.25], 2).tick
        end
      end
    end
  end
end
live_loop :G2022_01_02_006B do
  use_bpm 100
  with_synth :tb303 do
    play (ring 50, 51), amp: 1, attack: 0.125, sustain: 0.125
    sleep (stretch [0.5], 6, [0.25], 2).tick
  end
end
