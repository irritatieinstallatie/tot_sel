live_loop :G2021_00_00_002A do
  use_bpm 100
  with_synth :piano do
    with_fx :gverb, room: 77 do
      with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
        14.times do
          play 27, amp: 2,
            attack: 0.0125, decay: 0, sustain: rrand_i(0.1,1), release: 0.0125
          play (ring 26, 28), amp: 2,
            attack: 0.125, sustain: rrand_i(0,1), release: 0.125
          sleep (stretch [0.25],2,[0.5],1,[0.25],1,[0.5],2).tick
        end
        #        sleep 1
      end
    end
  end
end

