live_loop :G2022_01_20_042A do
  use_bpm 100
  with_synth :piano do
    with_fx :gverb, spread: 0.5, dry: 4, room: 55 do
      with_fx :ixi_techno, phase: 4 do
        with_fx :slicer, phase: 0.5,
        pulse_width: (line 0.125, 0.25, steps: 10).tick do
          play 77, amp: 4,
            attack: 0.05,
            release: 0.25,
            sustain: (line 0.01, 1, steps: 10).mirror.tick
          sleep 0.5
        end
      end
    end
  end
end
