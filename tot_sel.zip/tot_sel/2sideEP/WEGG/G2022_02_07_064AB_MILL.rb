live_loop :G2022_02_07_064A do
  #with_synth :tb303 do
  with_synth :piano do
    with_fx :slicer, phase: 0.5, pulse_width: 0.5 do
      play 44,
        amp: 1,
        attack: 0.1,
        sustain: 0.1,
        release: 0.1#,
        #        wave: 2,
        play 41,
        amp: 1,
        attack: 0.1,
        sustain: 0.1,
        release: 0.1#,
        #        wave: 2
      sleep (stretch
             [0.25], rrand_i(4,6),
             [0.125], rrand_i(1,2)
             ).mirror.tick
    end
  end
  # end
end


live_loop :G2022_02_07_064B do
  with_synth :tb303 do
    #  with_synth :piano do
    with_fx :slicer, phase: 0.25, pulse_width: 0.25 do
      play 44,
        amp: rrand_i(0,5),
        attack: 0.1,
        sustain: 0.1,
        release: 0.1,
        wave: 1
      play 41,
        amp: rrand_i(0,5),
        attack: 0.1,
        sustain: 0.1,
        release: 0.1,
        wave: 1
      sleep (stretch
             [0.125], rrand_i(8,12),
             [1.125],1,
             [0.25], rrand_i(4,6)
             ).mirror.tick
    end
  end
  # end
end
