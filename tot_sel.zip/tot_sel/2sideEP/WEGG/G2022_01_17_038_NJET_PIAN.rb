live_loop :G2022_01_17_038A do
  use_bpm 100
  with_synth :piano do
    with_fx :gverb, dry: 3, spread: 0.75, room: 55 do
      with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
        play 20, amp: 1.5,
          attack: 0.025,
          sustain: (stretch [rrand(0,0.5)],4,[0.25],4).tick,
          release: 0.0125,
          vel: 0.25
        sleep 0.5
      end
    end
  end
end
