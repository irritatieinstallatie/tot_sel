live_loop :G2022_01_13_032A do
  use_bpm 100
  n = 59
  with_synth :tb303 do
    with_fx :gverb, spread: 0.5, dry: 5, room: 77 do
      with_fx :slicer, phase: 0.5, pulse_width: 0.5 do
        play (ring n-1,n,n+1), amp: 6,
          attack: 0.05,
          decay: 0.1,
          sustain: 0,
          release: 0.05
        sleep 0.5
      end
    end
  end
end
live_loop :G2022_01_13_032B do
  use_bpm 100
  n = 59
  with_synth :pulse do
    with_fx :gverb, spread: 0.5, dry: 5, room: 77 do
      with_fx :slicer, phase: 0.5, pulse_width: 0.5 do
        play (ring n-1,n,n+1), amp: 3,
          attack: 0.01, attack_level: 0.05,
          decay: 0.5, decay_level: 0.01,
          sustain: 0.125,
          release: 0.01
        sleep 1
      end
    end
  end
end
