live_loop :G2022_02_07_062A do
  use_random_seed 101
  with_synth :tb303 do
    with_fx :slicer, phase: 0.5, pulse_width: 0.25 do
      play 44,
        amp: 1,
        attack: 0.1,
        sustain: 1,
        release: 0.1,
        wave: 2
      play 41,
        amp: 1,
        attack: 0.1,
        sustain: 1,
        release: 0.1,
        wave: 2
      #    sleep 0.25
      sleep (stretch
             [0.125],rrand_i(6,12),
             [0.25],rrand_i(3,6)
             ).mirror.tick
    end
  end
end
