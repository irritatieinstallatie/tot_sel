live_loop :G2022_01_09_025A do
  with_synth :tb303 do
    with_fx :gverb, room: 33 do
      play 31, amp: 2,
        attack: 0.0125, sustain: 0.25, release: 0.05
      play 39, amp: 2,
        attack: 0.0125, sustain: 0.25, release: 0.05
      sleep 1
    end
  end
end

live_loop :G2022_01_09_025B do
  with_synth :piano do
    with_fx :gverb, room: 33 do
      with_fx :slicer, phase: 0.25, pulse_width: 0.25 do
        play 31, amp: 2,
          attack: 0.0125, sustain: 0.125, release: 0.25
        play 39, amp: 2,
          attack: 0.0125, sustain: 0.125, release: 0.25
        sleep 0.25
      end
    end
  end
end
