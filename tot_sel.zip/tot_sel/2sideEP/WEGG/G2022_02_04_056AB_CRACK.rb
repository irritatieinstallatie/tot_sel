live_loop :G2022_01_09_020A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, dry: 1, spread: 1, room: 54 do
      with_fx :slicer, phase: 0.5, pulse_width: 0.5 do
        40.times do
          play 26, amp: (ring 0,2,0).tick,
            attack: 0.01,
            attack_level: 0.125,
            decay: 0,
            sustain: 0.75,
            release: 0.01
          sleep (stretch [0.25],24,
                 [0.5],2,
                 [0.25],12,
                 [0.5],2).tick
        end
      end
    end
  end
end
live_loop :G2022_01_01_005 do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, room: 22 do
      with_fx :slicer, pulse_width: 0.5, phase: 0.25 do
        play (ring 40.5, 41, 41.5), amp: 1,
          attack: 0.175, sustain: 1
        sleep (stretch [1], 8, [0.5], 1).tick
      end
    end
  end
end
