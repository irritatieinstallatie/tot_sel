live_loop :G2022_02_02_053A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :slicer, phase: 0.99, pulse_width: 0.25 do
      play 33,
        amp: 1,
        sustain: 0.5,
        wave: 2
      play 34,
        amp: 1,
        sustain: 0.5,
        wave: 2
      play 37,
        amp: (ring 0,0,0,0,0,1).tick,
        sustain: 0.5,
        wave: 2
      play 38,
        amp: (ring 0,0,0,0,0,1).tick,
        sustain: 0.5,
        wave: 2
      sleep (stretch
             [0.5],rrand_i(4,8),
             [0.25],rrand_i(8,12)#,
             #             [0.5],10
             ).mirror.tick
    end
  end
end
