live_loop :II153A4 do
  use_bpm 100
  n0 = rrand_i(18,24)
  with_synth :tb303 do
    with_fx :gverb, spread: 0.5, dry: 3, room: 77 do
      with_fx :bitcrusher,
      bits: 5, sample_rate: 44000 do
        n0.times do
          play 77, amp: 0.5,
            attack: 0.01,
            attack_level: 0.0,
            sustain: 0.125,
            decay: 0.0,
            #            decay_level: 0.5,
            release: 0.125,
            res: 0.75,
            wave: 0
          play 50, amp: 0.5,
            attack: 0.01,
            attack_level: 0.025,
            sustain: 0.125,
            decay: 0.00,
            #         decay_level: 0.5,
            release: 0.125,
            res: 0.75,
            wave: 0
          play 31, amp: 1.0,
            attack: 0.01,
            attack_level: 0.025,
            sustain: 0.125,
            decay: 0.0,
            #          decay_level: 0.5,
            release: 0.125,
            res: 0.75,
            wave: 2
          play 33, amp: 2.0,
            attack: 0.01,
            attack_level: 0.025,
            sustain: 0.125,
            decay: 0.0,
            #           decay_level: 0.5,
            release: 0.125,
            res: 0.75,
            wave: 2
          sleep 0.25
        end
      end
    end
  end
end

