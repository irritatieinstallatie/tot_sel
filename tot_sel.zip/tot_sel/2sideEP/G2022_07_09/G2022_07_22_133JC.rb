live_loop :G2022_07_22_133JC do
  use_bpm 100
  l1 = (ring 5,15).tick
  with_synth :blade do
    with_fx :gverb, spread: 0.5, dry: 5, room: 55 do
      with_fx :reverb, room: 0.5, mix: 0.7 do
        l1.times do
          play 50, amp: 1,
            attack_level: 1,
            attack: 0.001,
            sustain: (ring 0.125, 0.075).tick,
            release: 0.001,
            cutoff: 100
          play 60, amp: 1,
            attack_level: 1,
            attack: 0.001,
            sustain: (ring 0.125, 0.075).tick,
            release: 0.001,
            cutoff: 100
          play 70, amp: 1,
            attack_level: 1,
            attack: 0.001,
            sustain: (ring 0.125, 0.075).tick,
            release: 0.001,
            cutoff: 100
          play 80, amp: 1,
            attack_level: 1,
            attack: 0.001,
            sustain: (ring 0.125, 0.075).tick,
            release: 0.001,
            cutoff: 90
          #sleep 0.25
          sleep (stretch [0.125], 1, [0.25],4).tick
        end
      end
    end
  end
end

