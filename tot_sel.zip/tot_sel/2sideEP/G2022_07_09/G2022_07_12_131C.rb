live_loop :G2022_07_12_131C do
  use_bpm 100
  with_synth :blade do
    with_fx :gverb, spread: 0.5, dry: 4, room: 44 do
      12.times do
        play 70, amp: 1,
          attack_level: 1,
          attack: 0.001,
          sustain: (ring 0.125, 0.25, 0.5, 0.25, 0.125).tick,
          release: 0.001,
          vibrato_rate: 1,
          vibrato_depth: 0.15,
          vibrato_delay: 0.5,
          vibrato_onset: 0.1,
          env_curve: 1
        play (ring 60, 90), amp: 1,
          attack_level: 1,
          attack: 0.001,
          sustain: (ring 0.125, 0.25, 0.5, 0.25, 0.125).tick,
          release: 0.001,
          vibrato_rate: 1,
          vibrato_depth: 0.15,
          vibrato_delay: 0.5,
          vibrato_onset: 0.1,
          env_curve: 1,
          cutoff: 90
        play (ring 50, 60, 70, 80, 90), amp: 1,
          attack_level: 1,
          attack: 0.001,
          sustain: (ring 0.125, 0.25, 0.5, 0.25, 0.125).tick,
          release: 0.001,
          vibrato_rate: 1,
          vibrato_depth: 0.15,
          vibrato_delay: 0.5,
          vibrato_onset: 0.1,
          env_curve: 1,
          cutoff: 60
        play (ring 60, 70), amp: 2,
          attack_level: 1,
          attack: 0.001,
          sustain: (stretch [0.25],10,[0.5],2).tick,
          release: 0.001,
          vibrato_rate: 1,
          vibrato_depth: 0.15,
          vibrato_delay: 0.5,
          vibrato_onset: 0.1,
          env_curve: 1,
          cutoff: 110
        sleep (stretch [0.25], 2, [0.5],2, [0.25],6, [0.5],2).reflect.tick
      end
    end
  end
end
