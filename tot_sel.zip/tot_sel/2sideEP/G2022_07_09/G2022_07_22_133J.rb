live_loop :G2022_07_22_133J do
  use_bpm 100
  with_synth :blade do
    15.times do
      play 50, amp: 1,
        attack_level: 1,
        attack: 0.001,
        sustain: 0.125,
        release: 0.001,
        cutoff: 100
      play 60, amp: 1,
        attack_level: 1,
        attack: 0.001,
        sustain: 0.125,
        release: 0.001,
        cutoff: 100
      play 70, amp: 1,
        attack_level: 1,
        attack: 0.001,
        sustain: 0.25,
        release: 0.001,
        cutoff: 100
      #sleep 0.25
      sleep (stretch [0.25], 3, [0.5],1).tick
    end
  end
end

