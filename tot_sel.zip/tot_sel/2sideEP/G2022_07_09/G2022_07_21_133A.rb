live_loop :G2022_07_21_133A do
  use_bpm 100
  with_synth :blade do
    12.times do
      play 55, amp: 0.5,
        attack_level: 1,
        attack: 0.01,
        sustain: (stretch [0.25], 2, [1],1).tick,
        release: 0.01
      play 60, amp: 0.5,
        attack_level: 1,
        attack: 0.01,
        sustain: (stretch [0.25], 2, [1],1).tick,
        release: 0.01
      play 70, amp: 0.5,
        attack_level: 1,
        attack: 0.01,
        sustain: (stretch [0.25], 2, [1],1).tick,
        release: 0.01
      play (ring 70,80).tick, amp: 0.5,
        attack_level: 1,
        attack: 0.01,
        sustain: (stretch [0.25], 2, [1],1).tick,
        release: 0.01
      #sleep 0.25
      sleep (stretch [0.25], 2, [0.5],1).reflect.tick
    end
  end
end

