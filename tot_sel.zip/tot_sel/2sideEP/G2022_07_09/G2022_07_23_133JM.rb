live_loop :G2022_07_22_133JM do
  #  use_random_seed 107
  use_bpm 100
  with_synth :blade do
    with_fx :gverb, spread: 0.5, dry: 5, room: 55, mix: 0.5 do
      with_fx :reverb, room: 0.5, mix: 0.5 do
        12.times do
          play 60,
            amp: (line 0.5, 1, steps: 5).mirror.tick,
            attack_level: 1,
            attack: 0.001,
            sustain: (ring 0.125, 0.25).mirror.tick,
            release: 0.001
          play 61,
            amp: (line 0.5, 1, steps: 5).mirror.tick,
            attack_level: 1,
            attack: 0.001,
            sustain: (ring 0.125, 0.25).mirror.tick,
            release: 0.001
          play 62,
            amp: (line 0.5, 1, steps: 5).mirror.tick,
            attack_level: 1,
            attack: 0.001,
            sustain: (ring 0.125, 0.25).mirror.tick,
            release: 0.001
          play 69,
            amp: (line 0.5, 1, steps: 5).mirror.tick,
            attack_level: 1,
            attack: 0.001,
            sustain: (ring 0.125, 0.25).mirror.tick,
            release: 0.001
          #sleep 0.25
          sleep (stretch [0.125], 1, [0.25],1).reflect.tick
        end
      end
      #sleep (ring 0,1).tick
    end
  end
end

