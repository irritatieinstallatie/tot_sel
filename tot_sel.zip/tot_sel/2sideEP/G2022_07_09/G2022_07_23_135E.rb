live_loop :G2022_07_23_135E do
  #  use_random_seed 107
  use_bpm 100
  with_synth :blade do
    with_fx :gverb, spread: 0.5, dry: 5, room: 55, mix: 0.25 do
      with_fx :ixi_techno, phase: 48, phase_offset: 1, mix: 0.75  do
        with_fx :bitcrusher, bits: 4 do
          with_fx :reverb, room: 0.5, mix: 0.5 do
            24.times do
              play (ring 60,61),
                amp: 0.5,
                attack_level: 0.5,
                attack: 0.001,
                sustain: 0.25,
                release: 0.001
              play (ring 62,63),
                amp: 0.5,
                attack_level: 0.5,
                attack: 0.001,
                sustain: 0.125,
                release: 0.001
              play (ring 63,64),
                amp: 0.5,
                attack_level: 0.5,
                attack: 0.001,
                sustain: 0.25,
                release: 0.001
              play (ring 65,66),
                amp: 0.5,
                attack_level: 0.5,
                attack: 0.001,
                sustain: 0.125,
                release: 0.001
              play (ring 67,68),
                amp: 0.5,
                attack_level: 0.5,
                attack: 0.001,
                sustain: 0.125,
                release: 0.001
              play (ring 69,70),
                amp: 0.5,
                attack_level: 0.5,
                attack: 0.001,
                sustain: 0.125,
                release: 0.001
              #sleep 0.25
              sleep (stretch [0.25],
                     (ring 20,23).tick,
                     [0.5],
                     (ring 4,1).tick).tick
            end
          end
          #sleep (ring 0,1).tick
        end
      end
    end
  end
end
