live_loop :G2022_07_15_132A do
  use_bpm 100
  n1 = 24
  n2 = 29
  n3 = (ring 22,21,22).tick
  nx0 = (ring 4,2,4,2,3,2).tick
  with_synth :tb303 do
    with_fx :reverb, room: 0.7, mix: 0.25 do
      with_fx :bitcrusher,
        bits: 2.5,
      sample_rate: 44000 do
        nx0.times do
          play n1,
            amp: 2,
            attack: 0.001,
            sustain: 0.125,
            release: 0.001,
            wave: 2
          play n1+0.25, amp: 2,
            attack: 0.001,
            sustain: 0.125,
            release: 0.001,
            wave: 2
          play n1+0.5,
            amp: 2,
            attack: 0.001,
            sustain: 0.125,
            release: 0.001,
            wave: 2
          play n2,
            amp: 2,
            attack: 0.1,
            sustain: 0.5,
            release: 0.1,
            wave: 2
          play n3,
            amp: 1,
            attack: 0.1,
            sustain: 0.5,
            release: 0.1,
            wave: 2
          sleep 0.5
        end
      end
    end
  end
end
