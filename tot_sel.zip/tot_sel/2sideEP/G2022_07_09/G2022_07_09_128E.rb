
live_loop :G2022_06_09_128C do
  #  use_random_seed 8
  use_bpm 100
  with_synth :blade do
    with_fx :reverb, room: 0.75, mix: 0.25 do
      with_fx :slicer, phase: 0.5, pulse_width: 0.5, mix: 0.5 do
        20.times do
          play 50,
            amp: 1.0,
            attack: 0.01,
            sustain: 0.05,
            release: 0.01,
            vibrato_rate: 5,
            vibrato_depth: 0.5,
            vibrato_delay: 0.5,
            vibrato_onset: 0.1
          play 60,
            amp: 1.0,
            attack: 0.01,
            sustain: 0.05,
            release: 0.01,
            vibrato_rate: 5,
            vibrato_depth: 0.5,
            vibrato_delay: 0.5,
            vibrato_onset: 0.1
          play 80,
            amp: 1.0,
            attack: 0.01,
            sustain: 2,
            release: 0.01,
            vibrato_rate: 5,
            vibrato_depth: 0.25,
            vibrato_delay: 0.5,
            vibrato_onset: 0.1
          play 90,
            amp: 1.0,
            attack: 0.01,
            sustain: 2,
            release: 0.01,
            vibrato_rate: 5,
            vibrato_depth: 0.5,
            vibrato_delay: 0.5,
            vibrato_onset: 0.5
          sleep 0.5
        end
      end
    end
  end
end
