live_loop :G2022_07_12_131A do
  use_bpm 100
  with_synth :blade do
    with_fx :reverb, room: 0.5 do
      40.times do
        play (ring 60, 90), amp: 0.5,
          attack_level: 1,
          attack: 0.001,
          sustain: (stretch [0.25],(ring 8,12).tick, [0.125], 8).tick,
          release: 0.001,
          vibrato_rate: 6,
          vibrato_depth: 0.15,
          vibrato_delay: 0.5,
          vibrato_onset: 0.1,
          env_curve: 1,
          cutoff: 110
        play (ring 50, 60, 70, 80, 90), amp: 1,
          attack_level: 1,
          attack: 0.001,
          sustain: (stretch [0.25],(ring 4,4,2).tick, [0.125], 4).tick,
          release: 0.001,
          vibrato_rate: 6,
          vibrato_depth: 0.15,
          vibrato_delay: 0.5,
          vibrato_onset: 0.1,
          env_curve: 1,
          cutoff: 110
        sleep (stretch [0.25], 2,
               [0.5],2,
               [0.25],6,
               [0.5],2).reflect.tick
      end
    end
  end
end



