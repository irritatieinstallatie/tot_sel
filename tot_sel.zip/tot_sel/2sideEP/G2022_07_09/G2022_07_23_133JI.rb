live_loop :G2022_07_23_133JI do
  use_random_seed 107
  use_bpm 100
  #  l1 = (ring 12,15).tick
  with_synth :blade do
    with_fx :gverb, spread: 0.5, dry: 5, room: 55, mix: 0.5 do
      # with_fx :reverb, room: 0.5, mix: 0.5 do
      12.times do
        play 50,
          amp: (line 0.5, 1, steps: 5).choose,
          attack_level: 1,
          attack: 0.001,
          sustain: (ring 0.125, 0.25).tick,
          release: 0.001,
          cutoff: 100
        play 60,
          amp: (line 0.5, 1, steps: 5).choose,
          attack_level: 1,
          attack: 0.001,
          sustain: (ring 0.125, 0.25).tick,
          release: 0.001,
          cutoff: 100
        play 70,
          amp: (line 0.5, 1, steps: 5).choose,
          attack_level: 1,
          attack: 0.001,
          sustain: (ring 0.125, 0.25).tick,
          release: 0.001,
          cutoff: 100
        play 80,
          amp: (line 0.5, 1, steps: 5).choose,
          attack_level: 1,
          attack: 0.001,
          sustain: (ring 0.125, 0.25).tick,
          release: 0.001,
          cutoff: 90
        sleep 0.25
        #sleep (stretch [0.125], 1, [0.25],4).tick
      end
    end
    #sleep (ring 0,1).tick
    #end
  end
end

