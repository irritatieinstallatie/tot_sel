live_loop :II116AA2A2 do
  set_volume! 1
  use_bpm 100
  n1 = 27
  n2 = 28
  rc10 = rrand_i(4,8)
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: 2,
      pre_amp: 0.5,
    cutoff: 130 do
      with_fx :gverb,
        spread: 0.125,
        dry: 3,
        room: 44,
        pre_damp: 0.5,
        ref_level: 0.25,
        tail_level: 0.25,
        release: 5,
      mix: 0.75 do
        rc10.times do
          play n1,
            amp: 1,
            attack: 0.05,
            attack_level: 0,
            sustain: 0.5,
            decay: 0.125,
            decay_leve: 1,
            release: 0.001,
            res: 0.05,
            wave: 2
          play n1+0.25,
            amp: 1,
            attack: 0.05,
            attack_level: 0,
            sustain: 0.5,
            decay: 0.125,
            decay_leve: 1,
            release: 0.001,
            res: 0.05,
            wave: 2
          play n1+0.5,
            amp: 1,
            attack: 0.05,
            attack_level: 0,
            sustain: 0.25,
            decay: 0.25,
            decay_leve: 1,
            release: 0.001,
            res: 0.05,
            wave: 2
          play n2,
            amp: 1,
            attack: 0.05,
            attack_level: 0,
            sustain: 0.25,
            decay: 0.25,
            decay_leve: 1,
            release: 0.001,
            res: 0.05,
            wave: 0
          sleep 2
          #        sleep (ring 0.25, 0.5).reflect.tick
        end
      end
    end
  end
end
