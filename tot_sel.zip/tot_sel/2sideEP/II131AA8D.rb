

live_loop :II131AA8D do
  set_volume! 1
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, spread: 0.5, dry: 5, room: 77 do
      with_fx :krush, cutoff: 100, gain: 4 do
        1.times do
          play (ring 40, 42, 44, 46, 48, 50)+24, amp: 1,
            attack_level: 0.025,
            attack: 0.001,
            sustain: 0.25,
            release: 0.001,
            cutoff: 60
          sleep 0.25
        end
      end
    end
  end
end


