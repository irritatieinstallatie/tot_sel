live_loop :II_144C do
  use_bpm 100
  with_synth :tb303 do
    with_fx :reverb, room: 0.5, mix: 0.5 do
      with_fx :gverb, spread: 0.5, dry: 4, room: 55 do
        with_fx :bitcrusher,
          bits: 4,
        sample_rate: 44000 do
            12.times do
              play 66,
                amp: 1,
                attack: 0.0125,
                sustain: 0.125,
                decay: 0,
                decay_level: 1,
                release: 0.5,
                wave: 1,
                res: 0.5
              play 79,
                amp: 1,
                attack: 0.0125,
                sustain: 0.125,
                decay: 0,
                decay_level: 1,
                release: 0.5,
                wave: 1,
                res: 0.25
              play 33,
                amp: 1,
                attack: 0.125,
                sustain: 0.125,
                decay: 0,
                decay_level: 1,
                release: 0.5,
                wave: 1,
                res: 0.5
              
              sleep 0.25
            end
          end
        end
      end
  end
end
