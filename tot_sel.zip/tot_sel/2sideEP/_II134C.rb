live_loop :II134C do
  #  use_random_seed 107
  use_bpm 100
  with_synth :blade do
    with_fx :gverb, spread: 0.5, dry: 5, room: 55, mix: 0.25 do
      with_fx :bitcrusher, bits: 6 do
        64.times do
          play (ring 50, 41,60,62,69),
            amp: 1,
            attack_level: 1,
            attack: 0.001,
            sustain: 0.25,
            release: 0.001
          sleep 0.25
          #sleep (stretch [0.25],
          #      (ring 20,23).tick,
          #     [0.5],
          #    (ring 4,1).tick).tick
        end
      end
      sleep (ring 0,1).tick
      #     end
    end
  end
end
