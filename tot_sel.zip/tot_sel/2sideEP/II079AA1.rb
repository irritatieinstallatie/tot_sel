live_loop :II079AA1 do
  use_random_seed (ring 107, 101, 114, 115, 117, 121, 123, 124, 125, 126, 127, 128).choose
  use_bpm 100
  n1 = 23
  n2 = 29
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: 4,
    sample_rate: 33000 do
      with_fx :ixi_techno, phase: 0.5, phase_offset: 0.5, cutoff_min: 20, cutoff_max: 120 do
        #        with_fx :gverb, spread: 0.5, dry: 3, room: 22 do
        40.times do
          play n2,
            amp: 0.0,
            attack: 0.001,
            sustain: 0.125,
            release: 0.5,
            wave: 2
          play n1,
            amp: 1,
            attack: 0.05,
            sustain: 0.25,
            release: 0.25,
            wave: 2
          play n1+0.25, amp: 1,
            attack: 0.05,
            sustain: 0.25,
            release: 0.001,
            wave: 2
          play n1+0.5,
            amp: 1,
            attack: 0.05,
            sustain: 0.25,
            release: 0.001,
            wave: 2
          sleep 0.25
          play n1,
            amp: 2,
            attack: 0.05,
            sustain: 0.125,
            release: 0.005,
            wave: 2
          
          sleep 4
          #          sleep (stretch [0.5],20,[0.25],20).tick
        end
      end
      #     end
    end
  end
end
