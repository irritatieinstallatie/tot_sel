live_loop :II145B do
  set_volume! 1.000
  use_bpm 100
  n1 = 28
  n2 = 29
  rc10 = rrand_i(5,15)
  with_synth :tb303 do
    with_fx :gverb, spread: 0.5, dry: 0.5, room: 33 do
      with_fx :reverb, room: 0.5 do
        with_fx :bitcrusher,
          bits: 5,
        sample_rate: 44000 do
          rc10.times do
            play n1,
              amp: 1,
              attack: 0.001,
              attack_level: 0.5,
              sustain: 0.5,
              release: 0.001,
              release_level: 0.25,
              wave: 2,
              cutoff: 80
            play n1+0.25,
              amp: 1,
              attack: 0.001,
              attack_level: 0.5,
              sustain: 0.5,
              release: 0.001,
              release_level: 0.25,
              wave: 2,
              cutoff: 80
            play n1+0.5,
              amp: 1,
              attack: 0.001,
              attack_level: 0.5,
              sustain: 0.5,
              release: 0.001,
              release_level: 0.25,
              wave: 2,
              cutoff: 80
            play n2,
              amp: 1,
              attack: 0.001,
              attack_level: 0.5,
              sustain: 0.5,
              release: 0.001,
              release_level: 0.25,
              wave: 2,
              cutoff: 100
            sleep 0.25
          end
        end
      end
    end
  end
end
