live_loop :G2022_02_04_060BC do
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, room: 22 do
      with_fx :krush,
      res: 0.1 do
        with_fx :nrbpf,
          centre: (stretch [100],2, [90],4, [80],4,[75],2).mirror.tick,
        res: 0.25 do
          with_fx :ixi_techno, phase: 1,
            res: 0.1,
          mix: 0.5 do
            10.times do
              play (ring rrand(33,37), rrand(59, 63), rrand(47,55)), amp: rrand_i(1,2),
                attack: 0.05, sustain: 0.75, release: 0.05
              play (ring 33, 81, 96), amp: rrand_i(1,2),
                attack: 0.05, sustain: 0.75, release: 0.05
              play (ring 53, 59, 57), amp: rrand_i(1,2),
                attack: 0.05, sustain: 0.75, release: 0.05
              sleep 0.5
            end
          end
        end
      end
    end
  end
end
