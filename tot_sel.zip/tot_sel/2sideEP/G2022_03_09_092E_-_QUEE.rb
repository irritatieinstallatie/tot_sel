live_loop :G2022_03_09_092A do
  use_bpm 100
  with_synth :tb303 do
    with_fx :bitcrusher, bits: 3 do
      with_fx :panslicer, phase: 0.125, pulse_width: 0.25,
      mix: (stretch [1],10,[0], 1).reflect.tick do
        play 38.5, amp: (line 1,0,steps: 10).mirror.tick,
          attack: 0.125,
          sustain: 1,
          release: 0.125,
          wave: 2
        play 39, amp: (line 0,1,steps: 10).mirror.tick,
          attack: 0.125,
          sustain: 1,
          release: 0.125,
          wave: 2
        play 39.5, amp: (line 1,0,steps: 10).mirror.tick,
          attack: 0.125,
          sustain: 1,
          release: 0.125,
          wave: 2
        sleep 1
      end
    end
  end
end
