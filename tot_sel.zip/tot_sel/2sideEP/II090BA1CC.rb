set_volume! 1

live_loop :II090BA1CC do
  l48 = rrand_i(4,8)
  with_synth :tb303 do
    with_fx :bitcrusher,
      bits: (ring 2,3,4,5,6).reflect.tick,
    sample_rate: 44000 do
      with_fx :flanger, delay: 2, mix: (line 0,1, steps: l48).tick do
        with_fx :reverb, damp: 0.5, room: 0.75, mix: 0.5 do
          with_fx :gverb, spread: 0.4, dry: 4, room: 88, mix: (line 0,1, steps: l48).tick do
            l48.times  do
              play 25,
                amp: 1,
                attack: 0.01,
                sustain: 0.5,
                release: 0.01,
                res: 0.005,
                wave: 2
              play 26,
                amp: 1,
                attack: 0.1,
                sustain: 0.125,
                release: 0.1,
                res: 0.005,
                wave: 2
              sleep 0.5
            end
          end
        end
      end
    end
  end
end
