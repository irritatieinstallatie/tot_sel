
live_loop :II022A2 do
  use_bpm 100
  with_synth :tb303 do
    #    with_fx :slicer, phase: 0.5, pulse_width: 0.5 do
    play 45, amp: 1, attack: 0.01,
      sustain: 0.5, release: 0.01, wave: 1
    play 34, amp: 1, attack: 0.01,
      decay: 0.125, sustain: 0.25, release: 0.01, wave: 2
    play 65, amp: 1, attack: 0.01,
      sustain: 0.5, release: 0.01, wave: 1
    sleep 4
    
    #   sleep (stretch [0.25],24,[1],4,[2],4).tick
  end
  # end
end
