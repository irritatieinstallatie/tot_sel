live_loop :G2022_02_04_060E do
  use_random_seed 101
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, room: 22 do
      with_fx :krush,
      res: (line 0.1, 0.9, steps: rrand_i(4,21)).tick do
        with_fx :nrbpf,
        centre: (ring 100, 75, 50).tick, res: 0.5 do
          with_fx :ixi_techno, phase: 4, res: 0.5, mix: 0.5 do
            10.times do
              play (ring 53, 39, 57, 61, 69), amp: 1, attack: 0.05, sustain: 0.5, release: 0.05
              sleep (ring 0.125, 0.125, 0.25, 0.25).stretch(2).tick
            end
          end
        end
      end
    end
  end
end
