live_loop :II113C do
  #  use_random_seed 7
  use_bpm 100
  with_synth :tb303 do
    with_fx :gverb, spread: 0.5, dry: 4, room: 44 do
      with_fx :krush, gain: 5,
      res: 0.75 do
        with_fx :reverb, room: 0.4 do
          #with_fx :ixi_techno, phase: 4, res: 0.5, mix: 0.5 do
          60.times do
            play (ring 47),
              amp: 0.25,
              attack: 0.05, sustain: 0.5,
              release: 0.05#,
              #              wave: (ring 2,1,2).tick
              play (ring 47),
              amp: 0.25,
              attack: 0.05, sustain: 0.5,
              release: 0.05,
              wave: (ring 0,1,2).tick
            play (ring 47),
              amp: 0.25,
              attack: 0.05, sustain: 0.5,
              release: 0.05,
              wave: (ring 0,1,2).tick
            sleep 0.25
          end
        end
      end
    end
    #       end
  end
end


