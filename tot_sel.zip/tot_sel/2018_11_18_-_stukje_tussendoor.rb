use_random_seed 102



live_loop :tschrieuw do
  use_bpm 120
  #  op = rrand(0,1)
  with_fx :gverb, room: 9 do
    play 33, amp: 1, attack: 0.25, attack_level: 0.5, sustain: 0.125, release: 0.5
    play rrand_i(25, 32), amp: rrand(0.5, 1.5)
    play (ring 62, 62).stretch(1).tick, amp: 01, attack: 0, release: 0.125
  end
  sleep 1
  
  
end




