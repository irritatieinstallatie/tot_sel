#2019_01_22_002

use_bpm 120

use_random_seed rrand(0,101)
set_volume! 0.99





live_loop :hcja do
  
  with_synth :tb303 do
    with_fx :gverb, room: 11 do
      with_fx :krush do
        #        with_fx :nrbpf, centre: (ring 100, 75, 50).tick, res: 0.5 do
        with_fx :ixi_techno, phase: 4, res: 0.5, mix: 0.5 do
          28.times do
            play (ring 36, 59, 47).tick, amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
            play (ring 34, 81, 46), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
            play (ring 31, 49, 47), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
            sleep 0.25
          end
          '          14.times do
            play (ring rrand(33,37), rrand(59, 63), rrand(47,55)).choose, amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
            play (ring 33, 81, 96), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
            #play (ring 53, 59, 57), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
            sleep 0.5#   sleep (ring 0.25, 0.75).tick
          end'
          21.times do
            play (ring 33, 59, 47).choose, amp: 1, attack: 0.05, sustain: 0.125, release: 0.05
            play (ring 33, 81, 96), amp: 1, attack: 0.05, sustain: 0.125, release: 0.05
            #          play 44, sustain: 0.75
            play (ring 53, 59, 57), amp: 1, attack: 0.05, sustain: 0.125, release: 0.05
            sleep 0.25
          end
          '         7.times do
            play (ring 33, 59, 47), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
            play (ring 53, 39, 57, 81, 96).tick, amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
            sleep 0.5
          end'
          14.times do
            play (ring 53, 39, 57, 81, 96), amp: 1, attack: 0.05, sustain: 0.5, release: 0.05
            
            sleep (ring 0.25, 0.25, 0.5, 0.5).stretch(2).tick
          end
          
        end
      end
    end
    #   end
  end
end





live_loop :hcjb do
  use_bpm 20
  with_synth :hoover do
    with_fx :gverb, room: 21 do
      with_fx :nrbpf, centre: 75, res: 0.5 do
        with_fx :bitcrusher, bits: rrand_i(2,16), sample_rate: rrand_i(200, 44000) do
          #with_fx :flanger do
          if one_in(2)
            7.times do
              play (ring 36, 59, 47, 34, 81, 46).choose, amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
              play (ring 31, 49, 47), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
              sleep 0.25
            end
          else
            7.times do
              play (ring 36, 59, 47, 34, 81, 46).choose, amp: 7, attack: 0.05, sustain: 0.25, release: 0.05
              #play (ring 31, 49, 47), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
              sleep 0.25
            end
          end
          3.times do
            play (ring rrand(33,37), rrand(59, 63), rrand(47,55)).choose, amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
            play (ring 33, 81, 96), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
            play (ring 53, 59, 57), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
            sleep 0.5
          end
          if one_in(2)
            7.times do
              play (ring 43, 59, 47).choose, amp: 1, attack: 0.05, sustain: 0.125, release: 0.05
              play (ring 53, 51, 76), amp: 1, attack: 0.05, sustain: 0.125, release: 0.05
              #play 66
              play (ring 53, 59, 57), amp: 1, attack: 0.05, sustain: 0.125, release: 0.05
              sleep 0.25
            end
          else
            7.times do
              play (ring 33, 59, 47).choose, amp: 1, attack: 0.05, sustain: 0.125, release: 0.05
              play (ring 33, 81, 96), amp: 1, attack: 0.05, sustain: 0.125, release: 0.05
              #play 66
              play (ring 53, 59, 57), amp: 1, attack: 0.05, sustain: 0.125, release: 0.05
              sleep 0.25
            end
          end
          if one_in(2)
            3.times do
              play (ring 33, 59, 47).tick, amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
              play (ring 33, 81, 96), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
              play (ring 53, 59, 57), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
              sleep 0.5
            end
          else
            3.times do
              play (ring 33, 59, 47).tick, amp: 4, attack: 0.05, sustain: 0.25, release: 0.05
              play (ring 33, 81, 96), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
              play (ring 53, 59, 57), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
              sleep 0.5
            end
          end
        end
      end
    end
    #   end
  end
end






