set_volume! 0.9875



use_bpm 10







live_loop :sapperdezaag00 do
  zvntg = rrand(10,77)
  with_synth :supersaw do
    with_fx :gverb, room: 77 do
      with_fx :slicer, phase: 0.25, pulse_width: 0.25 do
        #3.times do
        20.times do
          play zvntg+7, attack: 0.25, release: 0.25, sustain: 1
          play zvntg+7.5, attack: 0.25, release: 0.25, sustain: 1
          play zvntg+8, attack: 0.25, release: 0.25, sustain: 1
          
          sleep (ring 0.125, 0.25, 0.125, 0.25, 0.125).tick
          
          #       end
          #          sleep 0.1
        end
      end
    end
  end
end

















live_loop :sapperdezaag01 do
  with_synth :dpulse do
    with_fx :gverb, room: 77 do
      with_fx :slicer, phase: (ring 0.25, 0.5, 0.125, 0.5, 0.125).tick, pulse_width: (ring 0.5, 0.5, 0.5, 0.5, 0.25).tick do
        20.times do
          play 77, attack: 0.25, release: 0.25, sustain: 1
          sleep (ring 0.125, 0.25, 0.125, 0.125, 0.25).tick
        end
      end
    end
  end
end










