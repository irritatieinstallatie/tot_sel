use_bpm 120

set_volume! 0.494

live_loop :minaers do

  zs00 = rrand_i(40, 50)
  zs01 =  60
  zs02 = (ring 69, 69, 69, 69, 69, 69).tick
  zs03 = (ring 67, 67, 67, 67, 67, 67).tick

  evenwicht = rrand_i(1,4)

  with_synth :tb303 do
    with_fx :gverb, room: 77 do
      cue :takeno01
      with_fx :bitcrusher, bits: 1, sample_rate: 4400 do
        with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
          play zs02, amp: 4, attack: 0.0125, sustain: 0.0, decay: 0, release: 0.125, wave: 1, res: (ring 0.5, 0.5, 0.95).tick
          play zs01, amp: 4, attack: 0.0125, sustain: 0.0, decay: 0, release: 0.125, wave: 1, res: (ring 0.5, 0.5, 0.95).tick
          play zs01, amp: 4, attack: 0.0125, sustain: 0.0, decay: 0, release: 0.125, wave: 1, res: (ring 0.5, 0.5, 0.95).tick
          sleep 4*(ring 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.25).stretch(3).tick
        end
        play rrand(90, 110), amp: 2, attack: rrand(0, 1)
      end
    end
  end
end
