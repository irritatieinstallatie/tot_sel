set_volume! 1

use_random_seed 11

use_bpm 100

dz = rrand(35,37)
vn = rrand(58,60)
vz = rrand(46,48)
dv = rrand(33,35)
te = rrand(80,82)
de = rrand(30,32)

live_loop :X2019_01_22_001 do
  #  with_synth (ring :zawa, :supersaw, :mod_dsaw, :prophet, :mod_pulse, :tb303).tick do
  with_synth (ring :supersaw, :prophet, :tb303).stretch(7).tick do
    #    with_fx :slicer, phase: 0.25 do
    100.times do
      play (ring dz, vn, vz).tick, amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
      play (ring dv, te, vz), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
      play (ring de, vn, vz), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
      sleep 0.25
    end
    
    
    
    
    
    #    sleep 0.125
    #   end
  end
end

live_loop :X2019_01_22_002 do
  #  with_synth (ring :zawa, :supersaw, :mod_dsaw, :prophet, :mod_pulse, :tb303).tick do
  with_synth (ring :supersaw, :prophet, :tb303).choose do
    
    100.times do
      sleep 0.25
      play (ring dz, vn, vz).tick, amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
      play (ring dv, te, vz), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
      play (ring de, vn, vz), amp: 1, attack: 0.05, sustain: 0.25, release: 0.05
    end
    
    
    
    
    
    #   sleep 0.25
  end
end

