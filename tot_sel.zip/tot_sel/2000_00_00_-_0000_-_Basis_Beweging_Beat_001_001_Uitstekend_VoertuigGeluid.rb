

live_loop :minaers do
  use_bpm 120
  with_synth :tb303 do
    with_fx :gverb, room: 77 do
      1.times do
        20.times do
          with_fx :bitcrusher,
            bits: 2,
          sample_rate: (line 23400, 10000, steps: 20).tick do
            #            with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
            play 67, amp: 1, attack: 0.0125, sustain: 0.0, decay: 0, release: 0.125, wave: 1, res: (ring 0.5, 0.5, 0.95).tick
            sleep 0.25
            #end
          end
        end
        if one_in(2)
          with_fx :slicer, phase: 0.5 do
            with_synth :chipbass do
              play 28, amp: rrand(4, 12),
                attack: 0.125,
                sustain: rrand(2.0, 4.0),
                release: 0.0
              sleep 0.5
            end
          end
        else
          with_fx :slicer, phase: 0.5 do
            play 96, amp: 1,
              attack: 0.0125,
              sustain: 1,
              release: 0.0625
            sleep 0.5
          end
        end
        
        #        play rrand(90, 110), amp: 2, attack: rrand(0, 1)
      end
      
    end
  end
end


