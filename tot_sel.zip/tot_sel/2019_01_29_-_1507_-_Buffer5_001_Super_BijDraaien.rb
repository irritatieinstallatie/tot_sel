use_random_seed 303

use_bpm 20

a01 = 2

a02 = 1

set_volume! 0.975


live_loop :zekersteonders do
  #flias  = (line: 100, 160, steps: 60)
  #use_bpm 120
  #use_bpm (line 100, 160, steps: 6).reflect.tick
  with_synth :tb303 do
    with_fx :gverb, room: 77 do
      with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
        #with_fx :level do
        14.times do

          play 27, amp: a01, attack: 0.00125, decay: (ring 0,0,0,0,1).stretch(2).tick, sustain: 0.125, release: 0.0125
          play (line 20, 32, steps: 10).choose, amp: a01, attack: 0.125, sustain: 0.5, release: 0.125
          sleep a02*(ring 1,1,1,(line 1, 0.75, steps: 10).tick).stretch(2).tick
        end
        #        sleep 1
      end
      #     end
    end
  end
end

zs00 = rrand_i(40, 50)
zs01 =  60
evenwicht = rrand_i(1,4)

live_loop :minaers do
  use_bpm 120
  with_synth :tb303 do
    with_fx :gverb, room: 77 do
      1.times do
        14.times do
          cue :takeno01
          with_fx :bitcrusher, bits: 1, sample_rate: 4400 do
            with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
              play (ring zs00+9, zs00+9, zs00+9, zs00+9, zs00+9, zs00+9, zs00+9).tick, amp: 2, attack: 0.0125, sustain: 0.0, decay: 0, release: 0.125, wave: 1, res: (ring 0.5, 0.5, 0.95).tick
              play (ring zs01+9, zs01+9, zs01+9, zs01+9, zs01+9, zs01+9, zs01+9).tick, amp: 2, attack: 0.0125, sustain: 0.0, decay: 0, release: 0.125, wave: 1, res: (ring 0.5, 0.5, 0.95).tick
              play (ring 67, 67, 67, 67, 67, 67, 67).tick, amp: 1, attack: 0.0125, sustain: 0.0, decay: 0, release: 0.125, wave: 1, res: (ring 0.5, 0.5, 0.95).tick
              sleep 2/evenwicht #(ring 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.25).stretch(3).tick
            end
          end
        end
        if one_in(2)
          play 98, amp: rrand(1, 7), attack: 0.0125, sustain: 0.0, release: 0.0625
          sleep 0.5
        else
          play 77, amp: 1, attack: 0.0125, sustain: 0.25*(ring 1,0,1,0,1,0).tick, release: 0.0625
          sleep 0.5
        end
        if one_in(2)
          with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
            evenwicht.times do
              play (ring zs00+9, zs00+9, zs00+9, zs00+9, zs00+9, zs00+9, zs00+9).tick, amp: 2, attack: 0.0125, sustain: evenwicht, decay: 0, release: 0.125, wave: 1, res: (ring 0.5, 0.5, 0.95).tick
              play (ring zs01+9, zs01+9, zs01+9, zs01+9, zs01+9, zs01+9, zs01+9).tick, amp: 2, attack: 0.0125, sustain: evenwicht, decay: 0, release: 0.125, wave: 1, res: (ring 0.5, 0.5, 0.95).tick
              play (ring 67, 67, 67, 67, 67, 67, 67).tick, amp: 1, attack: 0.0125, sustain: evenwicht, decay: 0, release: 0.125, wave: 1, res: (ring 0.5, 0.5, 0.95).tick
              sleep (ring 0.5, 0.5, 0.5, 0.25).stretch(1).tick
              sleep 1
            end
          end
        else
          sleep 0
        end

        #        play rrand(90, 110), amp: 2, attack: rrand(0, 1)
      end

    end
  end
end




live_loop :zambuba do
  with_synth :prophet do
    with_fx :compressor do
      use_bpm 60
      #    20.times do
      play (line 20, 40, steps: 40).reflect.choose, amp: 4.75, attack: 0.0125, sustain: 0.25, release: 0.125, threshold: 0.8
      sleep 0.25
      #   end
    end
  end
end







live_loop :sample20190127 do
  #  print sample_duration "/home/streekverkeer/Desktop/zekersteonders.wav"
  use_bpm 20
  with_fx :gverb, room: 3 do
    #    with_fx :slicer, phase: 0.5, pulse_width: (ring 0.1, 0.5, 0.9).tick do
    sync :takeno01
    7.times do
      #sample "/home/streekverkeer/Desktop/zekersteonders.wav",
      #            sustain: 3.47,
      #amp: rrand(4,7),
      # centre: 50, res: 0.5,
      #beat_stretch: 2.5,
      #start: 0.15, finish: 1
      #            rate: -1#, pitch_stretch: 2#, beat_stretch: 1#*(ring -1.0, -0.75, -0.5, -0.25, 0.25, 0.5, 0.75, 1).stretch(7).reflect.tick
      sleep 3.46/2.5
      #      print sample_duration "/home/streekverkeer/Desktop/zekersteonders.wav"
    end
    sleep rrand(1,2)
    #   end
  end
end
