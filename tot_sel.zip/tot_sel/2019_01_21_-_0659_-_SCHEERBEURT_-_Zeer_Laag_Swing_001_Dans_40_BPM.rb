set_volume! 0.75


use_bpm 40 #20


live_loop :sapperdezaag00 do
  
  use_bpm 20 #20
  
  zvntg = rrand(40,47)
  with_synth :supersaw do
    with_fx :gverb, room: 22 do
      with_fx :krush do
        with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
          #3.times do
          21.times do
            play zvntg+7, attack: 0.25, release: 0.25, sustain: 1
            play zvntg+7.5, attack: 0.25, release: 0.25, sustain: 1
            play zvntg+8, attack: 0.25, release: 0.25, sustain: 1
            
            sleep (ring 0.125, 0.25, 0.125, 0.25).tick
            
            #       end
            #          sleep 0.1
          end
        end
      end
    end
  end
end


live_loop :sapperdezaag01 do
  
  use_bpm 40 #20
  
  with_synth :dpulse do
    #with_fx :krush do
    with_fx :gverb, room: 22 do
      with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
        21.times do
          play 27, attack: 0.25, release: 0.25, sustain: 1
          
          sleep (ring 0.125, 0.25, 0.125, 0.25).tick
          
        end
        
      end
    end
    #end
  end
end




