use_random_seed 101

set_volume! 0.975

use_bpm 60

live_loop :ikzitwee do
  
  
  fraxit = (ring 1,2,3)
  
  
  with_synth :mod_dsaw do
    with_fx :gverb, room: 22 do
            with_fx :krush do
      with_fx :ixi_techno, phase: 22 do
        with_fx :nrbpf do
          with_fx :slicer, phase: 0.5, pulse_width: 0.95 do
            with_fx :echo do
              10.times do
                play (line 70, 110, steps: 10).choose,
                  #            play (line 50, 80, steps: 100).tick,
                  amp: 1,
                  attack: 0.125,
                  decay: 0.25,
                  sustain: rrand(2,4),
                  release: 0.125
                sleep rrand(0.5, 1.5)
              end
              sleep 10
            end
          end
        end
              end
      end
    end
  end
end








use_sample_bpm :ambi_piano

live_loop :pianolika01 do
  with_fx :slicer, phase: 0.125, pulse_width: 0.25 do
    
    
    #    print sample_duration :ambi_piano
    sample :ambi_piano,
      amp: 7,
      beat_stretch: 3,
      rate: 1
    
    sleep 1
    
  end
end








vrtg=49

on01 = rrand_i(1,4)
on02 = rrand_i(4,8)
on03 = rrand_i(1,4)
on04 = rrand_i(4,8)


on01 =  rrand_i(1,4)
or01 = rrand_i(10,20)
or02 = rrand_i(20,30)
or03 =  rrand_i(30,40)
or04 =  rrand_i(40,50)
or05 =  rrand_i(50,60)
or06 =    rrand_i(60,70)
or07 =    rrand_i(70,80)
or08 =    rrand_i(80,90)
or09 =    rrand_i(90,100)



amp1 = 0.95


live_loop :opena do
  
  use_bpm 60
  
  with_synth (ring :supersaw, :tb303, :chiplead).tick do
    
    # with_synth :sine do
    with_fx :gverb, room: 11 do
      #      with_fx :ixi_techno, phase: 2 do
      with_fx :slicer, phase: (ring 0.125, 0.25, 0.25, 0.25).stretch(2).tick,
      pulse_width: (ring 0.25, 0.5, 0.5, 0.5).stretch(2).tick do
        on03.times do
          play (ring or04, 40, or05), amp: 1, attack: 0.0125, decay: 0.125, release: 0.0125
          play (ring 50, or06, 60), amp: 1, attack: 0.0125, decay: 0.125, release: 0.0125
          play (ring 80, or09, 90), amp: 1, attack: 0.0125, decay: 0.125, release: 0.0125
          sleep 0.25
        end
        on04.times do
          play (ring or01, 10, or02), amp: 1, attack: 0.0125, decay: 0.125, release: 0.0125
          play (ring 80, or09, 90), amp: 1, attack: 0.0125, decay: 0.125, release: 0.0125
          sleep 0.25
        end
      end
    end
  end
  # end
end


