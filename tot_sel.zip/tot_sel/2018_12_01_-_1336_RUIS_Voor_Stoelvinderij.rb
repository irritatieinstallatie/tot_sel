use_bpm 100

set_volume! 1.0




live_loop :trui do
  with_synth :dark_ambience do
    with_fx :echo do
      #      play (line 20, 40, steps: 60).tick, amp: 3, attack: 0.01, sustain: 0.5, release: 0.01
      #      play (line 20, 40, steps: 60).reflect.tick, amp: 3, attack: 0.01, sustain: 0.5, release: 0.01
      #      play (line 21, 41, steps: 60).choose, amp: 4, attack: 0.01, sustain: 0.5, release: 0.01
      #     play (line 19, 39, steps: 60).choose, amp: 3, attack: 0.01, sustain: 0.5, release: 0.01
      #    play (line 18, 38, steps: 60).choose, amp: 1, attack: 0.01, sustain: 0.5, release: 0.01
      
      sleep 0.5*(ring 0.75, 0.5, 0.75, 0.75, 0.75, 0.5).tick
    end
  end
end






live_loop :weersverwachting do
  
  vrtg = 31
  with_synth :prophet do
    with_fx :reverb do
      #    7.times do
      21.times do
        play (ring vrtg+4.0,
              vrtg+4.4,
              vrtg+4.7,
              vrtg+4.1,
              vrtg+4.8,
              vrtg+4.5,
              vrtg+4.3,
        vrtg+4.9).choose,
          amp: 1
        #      amp: 0.9*(ring 1,2,1,2,1,2,3,2).choose
        sleep 0.5
      end
      sleep rrand(0,1)
      #      sleep 0.675*(ring 1, 2, 1, 1.5, 1, 2, 2, 2, 1).tick
      #   end
      
    end
    
  end
  
end















live_loop :poezie do
  
  with_synth :bnoise do
    with_fx :bitcrusher, bits: rrand_i(4,16), sample_rate: 44000 do
      with_fx :slicer, phase: 0.25 do
        #        sleep rrand(0.5,1)
        20.times do
          play 33, amp: 1, sustain: 0.125
          play 29, amp: 1, sustain: 0.125
          
          sleep (ring 0.125, 0.125, 0.0675).choose
          
          #          sleep 0.5*(ring 1,2,1,2,2,1,1,1,2,1).tick
        end
        
        20.times do
          play 33, amp: 1, sustain: 0.125
          play 37, amp: 1, sustain: 0.125, release: 0.125
          
          sleep (ring 0.125, 0.125, 0.0675).choose
          
          #          sleep 0.125*(ring 1,3,1,5,2,6,1,8,2,1).choose
        end
        20.times do
          play 33, amp: 1, sustain: 0.125
          play 31, amp: 1, sustain: 0.125
          
          sleep (ring 0.125, 0.125, 0.0675).choose
          
          #          sleep 0.25*(ring 1,3,1,5,2,6,1,8,2,1).choose
        end
        
      end
    end
  end
end













