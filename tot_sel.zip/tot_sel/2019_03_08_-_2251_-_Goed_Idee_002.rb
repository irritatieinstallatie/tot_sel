use_bpm 120

set_volume! 1.0

live_loop :maers01 do
  #use_bpm 120
  with_synth :tb303 do
    with_fx :gverb, room: 77 do
      1.times do
        64.times do
          with_fx :bitcrusher,
            #            bits: (line 1,16, steps: 16).tick,
            #           bits: (ring 12,8,4).tick,
            bits: (ring 1,2,4,8,16).tick,
          sample_rate: 44000 do
            #            with_fx :krush do
            #            with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
            play (line 44, 99, steps: 64).choose, amp: 1,
              attack: 0.0125,
              sustain: (line 0.125, 0.25, steps: 16).tick,
              decay: 0, release: 0.125,
              wave: 1,
              res: (ring 0.5, 0.5, 0.5, 0.25).tick
            sleep (ring 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25).tick
            #end
            #           end
          end
        end
      end
      sleep rrand(2,4)
    end
    
  end
end








live_loop :maers02 do
  #use_bpm 120
  with_synth :tb303 do
    with_fx :gverb, room: 77 do
      1.times do
        64.times do
          with_fx :bitcrusher,
            #            bits: (line 1,16, steps: 16).tick,
            bits: (ring 12,8,4).choose,
            #            bits: (ring 1,2,4,8,16).tick,
          sample_rate: 44000 do
            #            with_fx :krush do
            #            with_fx :slicer, phase: 0.25, pulse_width: 0.5 do
            play (line 26, 29, steps: 64).choose, amp: 0.9,
              attack: 0.0125,
              sustain: (line 0.125, 0.25, steps: 16).tick,
              decay: 0, release: 0.125,
              wave: 1,
              res: (ring 0.5, 0.5, 0.5, 0.25).choose
            sleep (ring 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25).tick
            #end
            #           end
          end
        end
      end
      sleep rrand(2,4)
    end
    
  end
end




